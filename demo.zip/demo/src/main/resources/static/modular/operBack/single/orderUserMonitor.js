/**
 * Created by zyl on 2018/4/4.
 */

/**
 * user单场比赛下单详情
 */
var OrderUser = {
    id: "OrderUserTable",	//表格id
    seItem: null,		//选中的条目
    table: null,
    layerIndex: -1
};


var play_dict = {"70102":"全场亚盘","70112":"半场亚盘",
    "70104":"全场大小","70114":"半场大小",
    "70133":"全场单双","70143":"半场单双",
    "70101":"全场欧盘","70111":"半场欧盘",
    "70150":"半场/全场","70170":"双重机会",
    "70103":"全场波胆","70113":"半场波胆",
    "70105":"全场总进球","70115":"半场总进球",
    "70130":"全场角球","70140":"半场角球"
}
var inplay_dict = {0:"滚球",1:"赛前"};

/**
 * 初始化表格的列
 */
OrderUser.initColumn = function () {
    var columns = [
        {field: 'selectItem', radio: true},
        {title: 'id', field: 'id', visible: false, align: 'center', valign: 'middle',width:'50px'},
        {title: '用户名', field: 'user_name', align: 'center', valign: 'middle', sortable: false},
        {title: '投注时间', field: 'pay_time', align: 'center', valign: 'middle', sortable: false},
        {title: '对阵ID', field: 'match_id', align: 'center', valign: 'middle', sortable: false},
        {title: '联赛', field: 'league_name', align: 'center', valign: 'middle', sortable: false},
        {title: '比赛时间', field: 'match_time', align: 'center', valign: 'middle', sortable: false},
        {title: '比赛', field: 'match_info', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var is_fh_finish = row.is_fh_finish;
                var home_team_name = row.home_team_name;
                var away_team_name = row.away_team_name;
                var is_finish = row.is_finish;
                var play_type = row.play_type;
                var match_info = "";
                if(play_type == 10){
                    if(is_fh_finish == 1){
                        match_info = home_team_name +" <font color=red> " + row.fh_home_score +" : " + row.fh_away_score +" </font> "+ away_team_name ;
                    }else{
                        match_info = home_team_name +" vs " + away_team_name;
                    }
                }else if(play_type == 20){
                    if(is_finish == 1){
                        match_info = home_team_name +" <font color=red> " + row.home_score +" : " + row.away_score +" </font> "+ away_team_name;
                    }else{
                        match_info = home_team_name +" vs " + away_team_name;
                    }
                }
                return match_info;
            }
        },
        {title: '类型', field: 'bets_type', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var play_id = row.play_id;
                var is_inplay = row.is_inplay;
                if(Feng.isEmpty(play_id)){
                    return row.bets_type;
                }
                return play_dict[play_id]+" - "+inplay_dict[is_inplay]
            }
        },
        {title: '下单时比分', field: 'score', align: 'center', valign: 'middle', sortable: false},
        {title: '投注项', field: 'bets_info', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                if(!Feng.isEmpty(row.bets_type)){
                    return;
                }else {
                    return row.CLIENT_PROPERTIES;
                }
            }
        },
        {title: '投注金额', field: 'item_money', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var item_money_b = row.bj;
                var item_money_c = row.cj;
                var item_money_1 = row.item_money_1;
                return ((item_money_b+item_money_c+item_money_1)+'').replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,');
            }
        },
        {title: '返奖金额', field: 'prize_money', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var prize_money = row.prize_money;
                var item_money_b = row.bj;
                var item_money_c = row.cj;
                var item_money_1 = row.item_money_1;
                var item_status = row.item_status;

                if(item_status == '-10'||item_status == '210'){
                    return ((item_money_b+item_money_c+item_money_1)+'').replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,');
                }else{
                    return (prize_money+'').replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,');
                }
                return 0;
            }},
        {title: '账户类别', field: 'item_cost', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var item_money_b = row.bj;
                var item_money_c = row.cj;
                var item_money_1 = row.item_money_1;
                if (item_money_b > 0 && item_money_c == 0){
                    return "本金"
                }else if(item_money_c > 0 && item_money_b ==0){
                    return "彩金"
                }else if(item_money_1 > 0 && item_money_c == 0 && item_money_b ==0){
                    return "全部"
                }else if(item_money_b >0 && item_money_c > 0){
                    return "本+彩"
                }
            }},
        {title: '投注明细', field: 'item_id', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                return '<a onclick=OrderUser.click_item_id(\''+row.item_id+'\')> 详情</a>';
            }}
        
    ]
    return columns;
};

//跳转到比赛详情
OrderUser.click_item_id=function (item_id) {
    Feng.layerOpen("投注详情","80%","80%","/Single/toOrderMonitorDetailPage/"+item_id)
}


/**
 * 搜索
 */
OrderUser.queryOrderMonitorOfOneUser = function () {
    var queryData = {};

    queryData['user_id'] = $("#user_id").val();
    queryData['match_id'] = $("#match_id").val();
    queryData['begin_time'] = $("#begin_time").val();
    queryData['end_time'] = $("#end_time").val();

    OrderUser.table.server_init(queryData);
}

$(function () {
    var defaultColunms = OrderUser.initColumn();
    var table = new BSTable(OrderUser.id, "/Single/queryOrderItemList", defaultColunms);
    var queryData = {};

    queryData['user_id'] = $("#user_id").val();
    queryData['match_id'] = $("#match_id").val();
    queryData['begin_time'] = $("#begin_time").val();
    queryData['end_time'] = $("#end_time").val();

    OrderUser.table = table.server_init(queryData);
});

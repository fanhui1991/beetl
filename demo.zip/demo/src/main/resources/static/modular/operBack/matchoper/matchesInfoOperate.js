/**
 * 赛事资料操盘
 */
var Operate = {
    id: "OperateTable",	//表格id
    id1: "OperateTable1",	//表格2 id
    seItem: null,		//选中的条目
    table: null,
    layerIndex: -1
};


var Operate1 = {
    id: "OperateTable1",	//表格2 id
    seItem: null,		//选中的条目
    table: null,
    layerIndex: -1
};

/**
 * 初始化表格的列
 */
Operate.initColumn = function () {
    var columns = [
        [
            {field: 'selectItem', radio: true},
            {title: 'id', field: 'id', visible: false, align: 'center', valign: 'middle',width:'50px'},
            {title: '联赛', field: 'leagueLive',  align: 'center',valign: 'middle', colspan: 1, rowspan: 2,formatter:
                function (value, row) {
                    var html = '';
                    var league_name = '&nbsp;';
                    if (null != row.league_name && "" != row.league_name
                        && undefined != row.league_name) {
                        league_name = row.league_name;
                    }

                    html += '<table border="1" width="100%" height="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;border-width:0px; border-style:hidden;">';
                    html += '<tr>';
                    html += '<td>' + league_name + '<br />&nbsp;<br />&nbsp;</td>';
                    html += '</tr>';
                    html += '<tr>';
                    html += '<td>滚<br />&nbsp;</td>';
                    html += '</tr>';
                    html += '</table>';
                    return html;
                }
            },
            {title: '时间', field: 'timeLive',   align: 'center',valign: 'middle', colspan: 1, rowspan: 2,formatter:
                function (value, row) {
                    var html = '';
                    var match_time = '&nbsp;';
                    var current_runing_time = '&nbsp;';
                    var status_name = '&nbsp;';

                    if (!Feng.isEmpty(row.match_time)) {
                        match_time = row.match_time;
                    }
                    if (!Feng.isEmpty(row.current_runing_time)) {
                        //小于1分钟 显示1分钟，超过一秒以上，算1分钟。（如61秒，显示2分钟）
                        if (parseInt(row.current_runing_time) <= 60) {
                            current_runing_time = 1 + "'";
                        } else {
                            var tmpNum = (row.current_runing_time / 60) + "";
                            if (tmpNum.indexOf(".") > 0) {
                                var num = tmpNum.substring(0, tmpNum.indexOf("."));
                                current_runing_time = parseInt(num) + 1 + "'";
                            } else {
                                current_runing_time = (row.current_runing_time / 60) + "'";
                            }
                        }
                    }
                    if (!Feng.isEmpty(row.status_name)) {
                        status_name = row.status_name;
                    }
                    html += '<table border="1" width="100%" height="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;border-width:0px; border-style:hidden;">';
                    html += '<tr>';
                    html += '<td>' + match_time + '</td>';
                    html += '</tr>';
                    html += '<tr>';
                    html += '<td>' + current_runing_time + '</td>';
                    html += '</tr>';
                    html += '<tr>';
                    html += '<td>' + status_name + '</td>';
                    html += '</tr>';
                    html += '<tr>';
                    html += '<td>&nbsp;<br />&nbsp;</td>';
                    html += '</tr>';
                    html += '</table>';
                    return html;
                }
            },
            {title: '比分', field: 'scoreLive',   align: 'center',valign: 'middle', colspan: 1, rowspan: 2,formatter:
                function (value, row) {
                    var html = '';
                    var home_goal_num = '&nbsp;';
                    var away_goal_num = '&nbsp;';
                    var fh_home_goal_num = '&nbsp;';
                    var fh_away_goal_num = '&nbsp;';

                    if (!Feng.isEmpty(row.home_goal_num)) {
                        home_goal_num = row.home_goal_num;
                    }
                    if (!Feng.isEmpty(row.away_goal_num)) {
                        away_goal_num = row.away_goal_num;
                    }
                    if (!Feng.isEmpty(row.fh_home_goal_num)) {
                        fh_home_goal_num = row.fh_home_goal_num;
                    }
                    if (!Feng.isEmpty(row.fh_away_goal_num)) {
                        fh_away_goal_num = row.fh_away_goal_num;
                    }

                    html += '<table border="1" width="100%" height="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;border-width:0px; border-style:hidden;">';
                    html += '<tr>';
                    html += '<td>' + home_goal_num + '-' + away_goal_num + '</td>';
                    html += '</tr>';
                    html += '<tr>';
                    html += '<td>（' + fh_home_goal_num + '-' + fh_away_goal_num + '）</td>';
                    html += '</tr>';
                    html += '<tr>';
                    html += '<td>&nbsp;</td>';
                    html += '</tr>';
                    html += '<tr>';
                    html += '<td>&nbsp;<br />&nbsp;</td>';
                    html += '</tr>';
                    html += '</table>';
                    return html;
                }
            },
            {title: '对阵', field: 'matchLive',  align: 'center', valign: 'middle', colspan: 1, rowspan: 2,formatter:
                function (value, row) {
                    var html = '';
                    var home_team_name = '&nbsp;';
                    var away_team_name = '&nbsp;';

                    if (!Feng.isEmpty(row.home_team_name)) {
                        home_team_name = row.home_team_name;
                    }
                    if (!Feng.isEmpty(row.away_team_name)) {
                        away_team_name = row.away_team_name;
                    }

                    html += '<table border="1" width="100%" height="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;border-width:0px; border-style:hidden;">';
                    html += '<tr>';
                    html += '<td>' + home_team_name + '</td>';
                    html += '</tr>';
                    html += '<tr>';
                    html += '<td>' + away_team_name + '</td>';
                    html += '</tr>';
                    html += '<tr>';
                    html += '<td>平</td>';
                    html += '</tr>';
                    html += '<tr>';
                    html += '<td>&nbsp;<br />&nbsp;</td>';
                    html += '</tr>';
                    html += '</table>';
                    return html;
                }
            },
            {title: '全场', align: 'center', valign: 'middle', colspan: 3},
            {title: '上半场', align: 'center', valign: 'middle', colspan: 3},
            {title: '操作', field: 'operateLive',  align: 'center', valign: 'middle', colspan: 1, rowspan: 2,formatter:
                function (value, row, index) {
                    var rowIndex = index;
                    var html = '';
                    /* 投注状态:  0 正常    1 滚球封盘   2赛前封盘  3滚球和赛前都封盘  7结束投注（终结状态）
                     二进制比特位开关解释如下
                     00  赛前和滚球都可投注
                     01  赛前可投注，滚球不可投注
                     10  赛前不可投注，滚球可投注
                     11  赛前和滚球都不可投注
                     111 结束投注（终结状态） */
                    if (parseInt(row.CTL_METHOD) == 0) {
                        html += '<button type="button" class="btn btn-success" onclick="betOperateLive(\'' + rowIndex + '\',\''+0+'\')">停止投注</button>';

                    } else if (parseInt(row.CTL_METHOD) == 1) {
                        html += '<button type="button" class="btn btn-warning" onclick="betOperateLive(\'' + rowIndex + '\',\''+1+'\')">开放投注</button>';
                    }

                    html += '<br /><br />';
                    return html;
                }
            }
        ],
        [
            {field: 'selectItem', radio: true},
            {title: 'id', field: 'id', visible: false, align: 'center', valign: 'middle',width:'50px'},
            {title: '欧', field: 'fullEuropeLive', align: 'center', valign: 'middle', sortable: false,formatter:
                function (value, row) {
                    var match_id = row.match_id;
                    var html = '';
                    var resultData;
                    var fixtrue_win = '&nbsp;';
                    var fixtrue_lost = '&nbsp;';
                    var fixtrue_draw = '&nbsp;';
                    var bet_status = '-1';
                    var ctl_method = '-1';
                    var sendData = {
                        'match_id': match_id,//赛事ID
                        'bet_type': 'EUROPE',//欧盘
                        'odds_phase': '3',//赔率阶段 1:早盘   2:今日盘  3:滚球盘
                        'match_phase': '0'
                    }
                    var ctl = row.CTL_METHOD;

                    var ajx = new $ax(Feng.ctxPath + "/Operate/queryMatchOddsByMatchId", function (data) {
                        if (!Feng.isEmpty(data.data)) {
                            resultData = JSON.parse(data.data[0].FIXTURE_ODDS);
                            fixtrue_win = resultData.w;
                            fixtrue_lost = resultData.l;
                            fixtrue_draw = resultData.d;
                            bet_status = data.data[0].bet_status;
                            ctl_method = data.data[0].CTL_METHOD;

                            var dataOne = new Array();
                            dataOne.push(data.data[0].match_group_id);
                            dataOne.push(data.data[0].ft_match_id);
                            dataOne.push(data.data[0].odds_phase);

                            html += '<table border="1" width="100%" height="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;border-width:0px; border-style:;">';
                            html += '<tr>';
                            html += '<td colspan="2"><font color="red">' + fixtrue_win + '</font></td>';
                            html += '</tr>';
                            html += '<tr>';
                            html += '<td colspan="2"><font color="red">' + fixtrue_lost + '</font></td>';
                            html += '</tr>';
                            html += '<tr>';
                            html += '<td colspan="2"><font color="red">' + fixtrue_draw + '</font></td>';
                            html += '</tr>';
                            html += '<tr>';
                            html += '<td>';

                            if (parseInt(ctl_method) == 0) {//投注状态: 0 正常    1 封盘
                                html += '<input type="radio" id="is_sys_fullEuropeLive' + match_id + '" name="is_sys_fullEuropeLive' + match_id
                                    + '"fh="1" dt="EUROPE" value="0" onclick="isSystemLive(this, \'' + dataOne + '\')" checked="checked"/>系统';
                                html += '<br />';
                                html += '<input type="radio" id="is_people_fullEuropeLive' + match_id + '" name="is_sys_fullEuropeLive' + match_id
                                    + '"fh="1" dt="EUROPE" value="1" onclick="isSystemLive(this, \'' + dataOne + '\')"/>人工';
                            } else if (parseInt(ctl_method) == 1) {
                                if (ctl == 1) {
                                    html += '<input type="radio" id="is_sys_fullEuropeLive' + match_id + '" name="is_sys_fullEuropeLive' + match_id
                                        + '"fh="1" dt="EUROPE" disabled="disabled" value="0" onclick="isSystemLive(this, \'' + dataOne + '\')"/>系统';
                                } else html += '<input type="radio" id="is_sys_fullEuropeLive' + match_id + '" name="is_sys_fullEuropeLive' + match_id
                                    + '"fh="1" dt="EUROPE" value="0" onclick="isSystemLive(this, \'' + dataOne + '\')"/>系统';
                                html += '<br />';
                                html += '<input type="radio" id="is_people_fullEuropeLive' + match_id + '" name="is_people_fullEuropeLive' + match_id
                                    + '"fh="1" dt="EUROPE" value="1" onclick="isSystemLive(this, \'' + dataOne + '\')" checked="checked"/>人工';
                            } else {
                                html += '&nbsp;';
                                html += '<br />';
                                html += '&nbsp;';
                            }

                            html += '</td>';
                            html += '</tr>';
                            html += '</table>';
                            // gridObjMatchLive.getColCells(colIndex)[rowIndex].innerHTML = html;
                        }
                    },function () {
                        Feng.error("queryMatchOddsByMatchId请求挂了```")
                    });
                    ajx.setData(sendData);
                    ajx.start();
                    return html
                }
            },
            {title: '亚', field: 'fullAsianLive', align: 'center', valign: 'middle', sortable: false,formatter:
                function (value, row) {
                    var match_id = row.match_id;
                    var html = '';
                    var resultData;
                    var fixtrue_win = '&nbsp;';
                    var fixtrue_lost = '&nbsp;';
                    var handicap_value = '';
                    var bet_status = '-1';
                    var ctl_method = '-1';
                    var ctl = row.CTL_METHOD;
                    var sendData = {
                        'match_id': match_id,//赛事ID
                        'bet_type': 'ASIAN',//亚盘
                        'odds_phase': '3',//赔率阶段 1:早盘   2:今日盘  3:滚球盘
                        'match_phase': '0'
                    }

                    var ajx = new $ax(Feng.ctxPath + "/Operate/queryMatchOddsByMatchId", function (data) {
                        if (!Feng.isEmpty(data.data)) {
                            resultData = JSON.parse(data.data[0].FIXTURE_ODDS);
                            fixtrue_win = resultData.w;
                            fixtrue_lost = resultData.l;
                            handicap_value = parseFloat(resultData.h) > 0 ? '+' + parseFloat(resultData.h) : parseFloat(resultData.h);
                            bet_status = data.data[0].bet_status;
                            ctl_method = data.data[0].CTL_METHOD;

                            var dataOne = new Array();
                            dataOne.push(data.data[0].match_group_id);
                            dataOne.push(data.data[0].ft_match_id);
                            dataOne.push(data.data[0].odds_phase);
                            dataOne.push(handicap_value);


                            html += '<table border="1" width="100%" height="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;border-width:0px; border-style:;">';
                            html += '<tr>';
                            html += '<td colspan="2">' + handicap_value + '&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">' + fixtrue_win + '</font></td>';
                            html += '</tr>';
                            html += '<tr>';
                            html += '<td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">' + fixtrue_lost + '</font></td>';
                            html += '</tr>';
                            html += '<tr>';
                            html += '<td colspan="2">&nbsp;</td>';
                            html += '</tr>';
                            html += '<tr>';
                            html += '<td>';

                            if (parseInt(ctl_method) == 0) {//投注状态: 0 正常    1 封盘
                                html += '<input type="radio" id="is_sys_fullAsianLive' + match_id + '" name="is_sys_fullAsianLive' + match_id + '"fh="1" dt="ASIAN" value="0" onclick="isSystemLive(this, \'' + dataOne + '\')" checked="checked"/>系统';
                                html += '<br />';
                                html += '<input type="radio" id="is_people_fullAsianLive' + match_id + '" name="is_sys_fullAsianLive' + match_id + '"fh="1" dt="ASIAN" value="1" onclick="isSystemLive(this, \'' + dataOne + '\')"/>人工';
                            } else if (parseInt(ctl_method) == 1) {
                                if (ctl == 1) {
                                    html += '<input type="radio" id="is_sys_fullAsianLive' + match_id + '" name="is_sys_fullAsianLive' + match_id + '"fh="1" dt="ASIAN" disabled="disabled" value="0" onclick="isSystemLive(this, \'' + dataOne + '\')"/>系统';
                                } else html += '<input type="radio" id="is_sys_fullAsianLive' + match_id + '" name="is_sys_fullAsianLive' + match_id + '"fh="1" dt="ASIAN" value="0" onclick="isSystemLive(this, \'' + dataOne + '\')"/>系统';
                                html += '<br />';
                                html += '<input type="radio" id="is_people_fullAsianLive' + match_id + '" name="is_people_fullAsianLive' + match_id + '"fh="1" dt="ASIAN" value="1" onclick="isSystemLive(this, \'' + dataOne + '\')" checked="checked"/>人工';
                            } else {
                                html += '&nbsp;';
                                html += '<br />';
                                html += '&nbsp;';
                            }

                            html += '</td>';
                            html += '</tr>';
                            html += '</table>';

                            // gridObjMatchLive.getColCells(colIndex)[rowIndex].innerHTML = html;
                        }
                    },function () {
                        Feng.error("queryMatchOddsByMatchId请求挂了```")
                    });
                    ajx.setData(sendData);
                    ajx.start();
                    return html
                }
            },
            {title: '大小', field: 'fullBigsmallLive', align: 'center', valign: 'middle', sortable: false,formatter:
                function (value, row) {
                    var match_id = row.match_id;
                    var html = '';
                    var resultData;
                    var fixtrue_big = '&nbsp;';
                    var fixtrue_small = '&nbsp;';
                    var handicap_value = '';
                    var big_handicap_value = '';
                    var small_handicap_value = '';
                    var bet_status = '-1';
                    var ctl_method = '-1';
                    var ctl = row.CTL_METHOD;
                    var sendData = {
                        'match_id': match_id,//赛事ID
                        'bet_type': 'BIGSMALL',//大小
                        'odds_phase': '3',//赔率阶段 1:早盘   2:今日盘  3:滚球盘
                        'match_phase': '0'
                    }

                    var ajx = new $ax(Feng.ctxPath + "/Operate/queryMatchOddsByMatchId", function (data) {
                        if (!Feng.isEmpty(data.data)) {
                            resultData = JSON.parse(data.data[0].FIXTURE_ODDS);
                            fixtrue_big = resultData.b;
                            fixtrue_small = resultData.s;
                            handicap_value = parseFloat(resultData.h);
                            big_handicap_value = '大' + handicap_value;
                            small_handicap_value = '小' + handicap_value;
                            bet_status = data.data[0].bet_status;
                            ctl_method = data.data[0].CTL_METHOD;

                            var dataOne = new Array();
                            dataOne.push(data.data[0].match_group_id);
                            dataOne.push(data.data[0].ft_match_id);
                            dataOne.push(data.data[0].odds_phase);
                            dataOne.push(handicap_value);

                            html += '<table border="1" width="100%" height="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;border-width:0px; border-style:;">';
                            html += '<tr>';
                            html += '<td colspan="2">' + big_handicap_value + '&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">' + fixtrue_big + '</font></td>';
                            html += '</tr>';
                            html += '<tr>';
                            html += '<td colspan="2">' + small_handicap_value + '&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">' + fixtrue_small + '</font></td>';
                            html += '</tr>';
                            html += '<tr>';
                            html += '<td colspan="2">&nbsp;</td>';
                            html += '</tr>';
                            html += '<tr>';
                            html += '<td>';

                            if (parseInt(ctl_method) == 0) {//投注状态: 0 正常    1 封盘
                                html += '<input type="radio" id="is_sys_fullBigsmallLive' + match_id + '" name="is_sys_fullBigsmallLive' + match_id + '"fh="1" dt="BIGSMALL" value="0" onclick="isSystemLive(this, \'' + dataOne + '\')" checked="checked"/>系统';
                                html += '<br />';
                                html += '<input type="radio" id="is_people_fullBigsmallLive' + match_id + '" name="is_people_fullBigsmallLive' + match_id + '"fh="1" dt="BIGSMALL" value="1" onclick="isSystemLive(this, \'' + dataOne + '\')"/>人工';
                            } else if (parseInt(ctl_method) == 1) {
                                if (ctl == 1) {
                                    html += '<input type="radio" id="is_sys_fullBigsmallLive' + match_id + '" name="is_sys_fullBigsmallLive' + match_id + '"fh="1" dt="BIGSMALL" disabled="disabled" value="0" onclick="isSystemLive(this, \'' + dataOne + '\')"/>系统';
                                } else html += '<input type="radio" id="is_sys_fullBigsmallLive' + match_id + '" name="is_sys_fullBigsmallLive' + match_id + '"fh="1" dt="BIGSMALL" value="0" onclick="isSystemLive(this, \'' + dataOne + '\')"/>系统';
                                html += '<br />';
                                html += '<input type="radio" id="is_people_fullBigsmallLive' + match_id + '" name="is_people_fullBigsmallLive' + match_id + '"fh="1" dt="BIGSMALL" value="1" onclick="isSystemLive(this, \'' + dataOne + '\')" checked="checked"/>人工';
                            } else {
                                html += '&nbsp;';
                                html += '<br />';
                                html += '&nbsp;';
                            }

                            html += '</td>';
                            html += '</tr>';
                            html += '</table>';

                            // gridObjMatchLive.getColCells(colIndex)[rowIndex].innerHTML = html;
                        }
                    },function () {
                        Feng.error("queryMatchOddsByMatchId请求挂了```")
                    });
                    ajx.setData(sendData);
                    ajx.start();
                    return html
                }
            },
            {title: '欧', field: 'halfEuropeLive', align: 'center', valign: 'middle', sortable: false,formatter:
                function (value, row) {
                    var match_id = row.match_id;
                    var html = '';
                    var resultData;
                    var fixtrue_win = '&nbsp;';
                    var fixtrue_lost = '&nbsp;';
                    var fixtrue_draw = '&nbsp;';
                    var bet_status = '-1';
                    var ctl_method = '-1';
                    var ctl = row.CTL_METHOD;
                    var sendData = {
                        'match_id': match_id,//赛事ID
                        'bet_type': 'EUROPE',//欧盘
                        'odds_phase': '3',//赔率阶段 1:早盘   2:今日盘  3:滚球盘
                        'match_phase': '1'//0:全场  1:上半场
                    }
                    var ajx = new $ax(Feng.ctxPath + "/Operate/queryMatchOddsByMatchId", function (data) {
                        if (!Feng.isEmpty(data.data)) {
                            resultData = data.data[0].FH_FIXTURE_ODDS;
                            if (!Feng.isEmpty(resultData)) {
                                resultData = JSON.parse(data.data[0].FH_FIXTURE_ODDS);
                                fixtrue_win = resultData.w;
                                fixtrue_lost = resultData.l;
                                fixtrue_draw = resultData.d;
                                bet_status = data.data[0].fh_bet_status;
                                ctl_method = data.data[0].fh_ctl_method;

                                var dataOne = new Array();
                                dataOne.push(data.data[0].match_group_id);
                                dataOne.push(data.data[0].ft_match_id);
                                dataOne.push(data.data[0].odds_phase);

                                html += '<table border="1" width="100%" height="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;border-width:0px; border-style:;">';
                                html += '<tr>';
                                html += '<td colspan="2"><font color="red">' + fixtrue_win + '</font></td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td colspan="2"><font color="red">' + fixtrue_lost + '</font></td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td colspan="2"><font color="red">' + fixtrue_draw + '</font></td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td>';

                                if (parseInt(ctl_method) == 0) {//投注状态: 0 正常    1 封盘
                                    html += '<input type="radio" id="is_sys_halfEuropeLive' + match_id + '" name="is_sys_halfEuropeLive' + match_id + '"fh="0" dt="EUROPE" value="0" onclick="isSystemLive(this, \'' + dataOne + '\')" checked="checked"/>系统';
                                    html += '<br />';
                                    html += '<input type="radio" id="is_people_halfEuropeLive' + match_id + '" name="is_sys_halfEuropeLive' + match_id + '"fh="0" dt="EUROPE" value="1" onclick="isSystemLive(this, \'' + dataOne + '\')"/>人工';
                                } else if (parseInt(ctl_method) == 1) {
                                    if (ctl == 1) {
                                        html += '<input type="radio" id="is_sys_halfEuropeLive' + match_id + '" name="is_sys_halfEuropeLive' + match_id + '"fh="0" dt="EUROPE" disabled="disabled" value="0" onclick="isSystemLive(this, \'' + dataOne + '\')"/>系统';
                                    } else html += '<input type="radio" id="is_sys_halfEuropeLive' + match_id + '" name="is_sys_halfEuropeLive' + match_id + '"fh="0" dt="EUROPE" value="0" onclick="isSystemLive(this, \'' + dataOne + '\')"/>系统';
                                    html += '<br />';
                                    html += '<input type="radio" id="is_people_halfEuropeLive' + match_id + '" name="is_sys_halfEuropeLive' + match_id + '"fh="0" dt="EUROPE" value="1" onclick="isSystemLive(this, \'' + dataOne + '\')" checked="checked"/>人工';
                                } else {
                                    html += '&nbsp;';
                                    html += '<br />';
                                    html += '&nbsp;';
                                }

                                html += '</td>';
                                html += '</tr>';
                                html += '</table>';

                                // gridObjMatchLive.getColCells(colIndex)[rowIndex].innerHTML = html;
                            }
                        }
                    },function () {
                        Feng.error("queryMatchOddsByMatchId请求挂了```")
                    });
                    ajx.setData(sendData);
                    ajx.start();
                    return html
                }
            },
            {title: '亚', field: 'halfAsianLive', align: 'center', valign: 'middle', sortable: false,formatter:
                function (value, row) {
                    var match_id = row.match_id;
                    var html = '';
                    var resultData;
                    var fixtrue_win = '&nbsp;';
                    var fixtrue_lost = '&nbsp;';
                    var handicap_value = '';
                    var bet_status = '-1';
                    var ctl_method = '-1';
                    var ctl = row.CTL_METHOD;
                    var sendData = {
                        'match_id': match_id,//赛事ID
                        'bet_type': 'ASIAN',//亚盘
                        'odds_phase': '3',//赔率阶段 1:早盘   2:今日盘  3:滚球盘
                        'match_phase': '1'//0:全场  1:上半场
                    }

                    var ajx = new $ax(Feng.ctxPath + "/Operate/queryMatchOddsByMatchId", function (data) {
                        if (!Feng.isEmpty(data.data)) {
                            resultData = data.data[0].FH_FIXTURE_ODDS;
                            if (!Feng.isEmpty(resultData)) {
                                resultData = JSON.parse(data.data[0].FH_FIXTURE_ODDS);
                                fixtrue_win = resultData.w;
                                fixtrue_lost = resultData.l;
                                handicap_value = parseFloat(resultData.h) > 0 ? '+' + parseFloat(resultData.h) : parseFloat(resultData.h);
                                bet_status = data.data[0].fh_bet_status;
                                ctl_method = data.data[0].fh_ctl_method;

                                var dataOne = new Array();
                                dataOne.push(data.data[0].match_group_id);
                                dataOne.push(data.data[0].ft_match_id);
                                dataOne.push(data.data[0].odds_phase);
                                dataOne.push(handicap_value);

                                html += '<table border="1" width="100%" height="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;border-width:0px; border-style:;">';
                                html += '<tr>';
                                html += '<td colspan="2">' + handicap_value + '&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">' + fixtrue_win + '</font></td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">' + fixtrue_lost + '</font></td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td colspan="2">&nbsp;</td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td>';

                                if (parseInt(ctl_method) == 0) {//投注状态: 0 正常    1 封盘
                                    html += '<input type="radio" id="is_sys_halfAsianLive' + match_id + '" name="is_sys_halfAsianLive' + match_id + '"fh="0" dt="ASIAN" value="0" onclick="isSystemLive(this, \'' + dataOne + '\')" checked="checked"/>系统';
                                    html += '<br />';
                                    html += '<input type="radio" id="is_people_halfAsianLive' + match_id + '" name="is_sys_halfAsianLive' + match_id + '"fh="0" dt="ASIAN" value="1" onclick="isSystemLive(this, \'' + dataOne + '\')"/>人工';
                                } else if (parseInt(ctl_method) == 1) {
                                    if (ctl == 1) {
                                        html += '<input type="radio" id="is_sys_halfAsianLive' + match_id + '" name="is_sys_halfAsianLive' + match_id + '"fh="0" dt="ASIAN" disabled="disabled" value="0" onclick="isSystemLive(this, \'' + dataOne + '\')"/>系统';
                                    } else html += '<input type="radio" id="is_sys_halfAsianLive' + match_id + '" name="is_sys_halfAsianLive' + match_id + '"fh="0" dt="ASIAN" value="0" onclick="isSystemLive(this, \'' + dataOne + '\')"/>系统';
                                    html += '<br />';
                                    html += '<input type="radio" id="is_people_halfAsianLive' + match_id + '" name="is_sys_halfAsianLive' + match_id + '"fh="0" dt="ASIAN" value="1" onclick="isSystemLive(this, \'' + dataOne + '\')" checked="checked"/>人工';
                                } else {
                                    html += '&nbsp;';
                                    html += '<br />';
                                    html += '&nbsp;';
                                }

                                html += '</td>';
                                html += '</tr>';
                                html += '</table>';

                                // gridObjMatchLive.getColCells(colIndex)[rowIndex].innerHTML = html;
                            }
                        }
                    },function () {
                        Feng.error("queryMatchOddsByMatchId请求挂了```")
                    });
                    ajx.setData(sendData);
                    ajx.start();
                    return html
                }
            },
            {title: '大小', field: 'halfBigsmallLive', align: 'center', valign: 'middle', sortable: false,formatter:
                function (value, row) {
                    var match_id = row.match_id;
                    var html = '';
                    var resultData;
                    var fixtrue_big = '&nbsp;';
                    var fixtrue_small = '&nbsp;';
                    var handicap_value = '';
                    var big_handicap_value = '';
                    var small_handicap_value = '';
                    var bet_status = '-1';
                    var ctl_method = '-1';
                    var ctl = row.CTL_METHOD;
                    var sendData = {
                        'match_id': match_id,//赛事ID
                        'bet_type': 'BIGSMALL',//大小
                        'odds_phase': '3',//赔率阶段 1:早盘   2:今日盘  3:滚球盘
                        'match_phase': '1'//0:全场  1:上半场
                    }

                    var ajx = new $ax(Feng.ctxPath + "/Operate/queryMatchOddsByMatchId", function (data) {
                        if (!Feng.isEmpty(data.data)) {
                            resultData = data.data[0].FH_FIXTURE_ODDS;
                            if (!Feng.isEmpty(resultData)) {
                                resultData = JSON.parse(data.data[0].FH_FIXTURE_ODDS);
                                fixtrue_big = resultData.b;
                                fixtrue_small = resultData.s;
                                handicap_value = parseFloat(resultData.h);
                                big_handicap_value = '大' + handicap_value;
                                small_handicap_value = '小' + handicap_value;
                                bet_status = data.data[0].fh_bet_status;
                                ctl_method = data.data[0].fh_ctl_method;

                                var dataOne = new Array();
                                dataOne.push(data.data[0].match_group_id);
                                dataOne.push(data.data[0].ft_match_id);
                                dataOne.push(data.data[0].odds_phase);
                                dataOne.push(handicap_value);

                                html += '<table border="1" width="100%" height="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;border-width:0px; border-style:;">';
                                html += '<tr>';
                                html += '<td colspan="2">' + big_handicap_value + '&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">' + fixtrue_big + '</font></td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td colspan="2">' + small_handicap_value + '&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">' + fixtrue_small + '</font></td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td colspan="2">&nbsp;</td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td>';

                                if (parseInt(ctl_method) == 0) {//投注状态: 0 正常    1 封盘
                                    html += '<input type="radio" id="is_sys_halfBigsmallLive' + match_id + '" name="is_sys_halfBigsmallLive' + match_id + '"fh="0" dt="BIGSMALL" value="0" onclick="isSystemLive(this, \'' + dataOne + '\')" checked="checked"/>系统';
                                    html += '<br />';
                                    html += '<input type="radio" id="is_people_halfBigsmallLive' + match_id + '" name="is_sys_halfBigsmallLive' + match_id + '"fh="0" dt="BIGSMALL" value="1" onclick="isSystemLive(this, \'' + dataOne + '\')"/>人工';
                                } else if (parseInt(ctl_method) == 1) {
                                    if (ctl == 1) {
                                        html += '<input type="radio" id="is_people_halfBigsmallLive' + match_id + '" name="is_sys_fullEuropeLive' + match_id + '"fh="0" dt="BIGSMALL" disabled="disabled" value="0" onclick="isSystemLive(this, \'' + dataOne + '\')"/>系统';
                                    } else html += '<input type="radio" id="is_people_halfBigsmallLive' + match_id + '" name="is_sys_fullEuropeLive' + match_id + '"fh="0" dt="BIGSMALL" value="0" onclick="isSystemLive(this, \'' + dataOne + '\')"/>系统';
                                    html += '<br />';
                                    html += '<input type="radio" id="is_people_halfBigsmallLive' + match_id + '" name="is_people_halfBigsmallLive' + match_id + '"fh="0" dt="BIGSMALL" value="1" onclick="isSystemLive(this, \'' + dataOne + '\')" checked="checked"/>人工';
                                } else {
                                    html += '&nbsp;';
                                    html += '<br />';
                                    html += '&nbsp;';
                                }

                                html += '</td>';
                                html += '</tr>';
                                html += '</table>';

                                // gridObjMatchLive.getColCells(colIndex)[rowIndex].innerHTML = html;
                            }
                        }
                    },function () {
                        Feng.error("queryMatchOddsByMatchId请求挂了```")
                    });
                    ajx.setData(sendData);
                    ajx.start();
                    return html
                }
            }
        ]
    ]
    return columns;
};


Operate1.initColumn1 = function () {
    var columns = [
        [
            {field: 'selectItem', radio: true},
            {title: 'id', field: 'id', visible: false, align: 'center', valign: 'middle',width:'50px'},
            {title: '联赛', field: 'leagueBefore',  align: 'center',valign: 'middle', colspan: 1, rowspan: 2,formatter:
                function (value, row) {
                    var html = '';
                    var league_name = '&nbsp;';
                    if (!Feng.isEmpty(row.league_name)) {
                        league_name = row.league_name;
                    }

                    html += '<table border="1" width="100%" height="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;border-width:0px; border-style:hidden;">';
                    html += '<tr>';
                    html += '<td>' + league_name + '</td>';
                    html += '</tr>';
                    html += '</table>';
                    return html;
                }
            },
            {title: '时间', field: 'timeBefore',   align: 'center',valign: 'middle', colspan: 1, rowspan: 2,formatter:
                function (value, row) {
                    var html = '';
                    var match_time = '&nbsp;';
                    var current_runing_time = '&nbsp;';
                    var status_name = '&nbsp;';

                    if (!Feng.isEmpty(row.match_time)) {
                        match_time = row.match_time;
                    }
                    if (!Feng.isEmpty(row.status_name)) {
                        status_name = row.status_name;
                    }

                    html += '<table border="1" width="100%" height="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;border-width:0px; border-style:hidden;">';
                    html += '<tr>';
                    html += '<td>' + match_time + '</td>';
                    html += '</tr>';
                    html += '<tr>';
                    html += '<td>' + current_runing_time + '</td>';
                    html += '</tr>';
                    html += '<tr>';
                    html += '<td>' + status_name + '</td>';
                    html += '</tr>';
                    html += '<tr>';
                    html += '<td>&nbsp;<br />&nbsp;</td>';
                    html += '</tr>';
                    html += '</table>';
                    return html;
                }
            },
            {title: '比分', field: 'scoreBefore',   align: 'center',valign: 'middle', colspan: 1, rowspan: 2,formatter:
                function (value, row) {
                    var html = '';
                    var home_goal_num = '&nbsp;';
                    var away_goal_num = '&nbsp;';
                    var fh_home_goal_num = '&nbsp;';
                    var fh_away_goal_num = '&nbsp;';

                    html += '<table border="1" width="100%" height="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;border-width:0px; border-style:hidden;">';
                    html += '<tr>';
                    html += '<td>' + home_goal_num + '' + away_goal_num + '</td>';
                    html += '</tr>';
                    html += '<tr>';
                    html += '<td>' + fh_home_goal_num + '' + fh_away_goal_num + '</td>';
                    html += '</tr>';
                    html += '<tr>';
                    html += '<td>&nbsp;</td>';
                    html += '</tr>';
                    html += '<tr>';
                    html += '<td>&nbsp;<br />&nbsp;</td>';
                    html += '</tr>';
                    html += '</table>';
                    return html;
                }
            },
            {title: '对阵', field: 'matchBefore',  align: 'center', valign: 'middle', colspan: 1, rowspan: 2,formatter:
                function (value, row) {
                    var html = '';
                    var home_team_name = '&nbsp;';
                    var away_team_name = '&nbsp;';

                    if (!Feng.isEmpty(row.home_team_name)) {
                        home_team_name = row.home_team_name;
                    }
                    if (!Feng.isEmpty(row.away_team_name)) {
                        away_team_name = row.away_team_name;
                    }

                    html += '<table border="1" width="100%" height="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;border-width:0px; border-style:hidden;">';
                    html += '<tr>';
                    html += '<td>' + home_team_name + '</td>';
                    html += '</tr>';
                    html += '<tr>';
                    html += '<td>' + away_team_name + '</td>';
                    html += '</tr>';
                    html += '<tr>';
                    html += '<td>平</td>';
                    html += '</tr>';
                    html += '<tr>';
                    html += '<td>&nbsp;<br />&nbsp;</td>';
                    html += '</tr>';
                    html += '</table>';
                    return html;
                }
            },
            {title: '全场', align: 'center', valign: 'middle', colspan: 3},
            {title: '上半场', align: 'center', valign: 'middle', colspan: 3},
            {title: '操作', field: 'operateBefore',  align: 'center', valign: 'middle', colspan: 1, rowspan: 2,formatter:
                function (value, row, index) {
                    var rowIndex = index;//取得行记录数据
                    var html = '';
                    /* 投注状态:  0 正常    1 滚球封盘   2赛前封盘  3滚球和赛前都封盘  7结束投注（终结状态）
                     二进制比特位开关解释如下
                     00  赛前和滚球都可投注
                     01  赛前可投注，滚球不可投注
                     10  赛前不可投注，滚球可投注
                     11  赛前和滚球都不可投注
                     111 结束投注（终结状态） */
                    if (parseInt(row.CTL_METHOD) == 0) {
                        html += '<button type="button" class="btn btn-success" onclick="betOperateBefore(\'' + rowIndex + '\',\''+0+'\')";>停止投注</button>';
                    } else if (parseInt(row.CTL_METHOD) == 1) {
                        html += '<button type="button" class="btn btn-warning" onclick="betOperateBefore(\'' + rowIndex + '\',\''+1+'\')";>开放投注</button>';
                    }

                    html += '<br /><br />';
                    return html;
                }
            }
        ],
        [
            {field: 'selectItem', radio: true},
            {title: 'id', field: 'id', visible: false, align: 'center', valign: 'middle',width:'50px'},
            {title: '欧', field: 'fullEuropeBefore', align: 'center', valign: 'middle', sortable: false,formatter:
                function (value, row) {
                    var match_id = row.match_id;
                    var html = '';
                    var resultData;
                    var fixtrue_win = '&nbsp;';
                    var fixtrue_lost = '&nbsp;';
                    var fixtrue_draw = '&nbsp;';
                    var bet_status = '-1';
                    var ctl_method = '-1';
                    var ctl = row.CTL_METHOD;
                    var sendData = {
                        'match_id': match_id,//赛事ID
                        'bet_type': 'EUROPE',//欧盘
                        'odds_phase': '1,2',//赔率阶段 1:早盘   2:今日盘  3:滚球盘
                        'match_phase': '0'
                    }

                    var ajx = new $ax(Feng.ctxPath + "/Operate/queryMatchOddsByMatchId", function (data) {
                        if (!Feng.isEmpty(data.data)) {
                            resultData = JSON.parse(data.data[0].FIXTURE_ODDS);
                            if (!Feng.isEmpty(resultData)) {
                                fixtrue_win = resultData.w;
                                fixtrue_lost = resultData.l;
                                fixtrue_draw = resultData.d;
                                bet_status = data.data[0].bet_status;
                                ctl_method = data.data[0].CTL_METHOD;

                                var dataOne = new Array();
                                dataOne.push(data.data[0].match_group_id);
                                dataOne.push(data.data[0].ft_match_id);
                                dataOne.push(data.data[0].odds_phase);

                                html += '<table border="1" width="100%" height="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;border-width:0px; border-style:;">';
                                html += '<tr>';
                                html += '<td colspan="2"><font color="red">' + fixtrue_win + '</font></td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td colspan="2"><font color="red">' + fixtrue_lost + '</font></td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td colspan="2"><font color="red">' + fixtrue_draw + '</font></td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td>';

                                if (parseInt(ctl_method) == 0) {//投注状态: 0 正常    1 封盘
                                    html += '<input type="radio" id="is_sys_fullEuropeBefore' + match_id + '" name="is_sys_fullEuropeBefore' + match_id + '"fh="1" dt="EUROPE" value="0" onclick="isSystemBefore(this, \'' + dataOne + '\')" checked="checked"/>系统';
                                    html += '<br />';
                                    html += '<input type="radio" id="is_people_fullEuropeBefore' + match_id + '" name="is_sys_fullEuropeBefore' + match_id + '"fh="1" dt="EUROPE" value="1" onclick="isSystemBefore(this, \'' + dataOne + '\')"/>人工';
                                } else if (parseInt(ctl_method) == 1) {
                                    if (ctl == 1) {
                                        html += '<input type="radio" id="is_sys_fullEuropeBefore' + match_id + '" name="is_sys_fullEuropeBefore' + match_id + '"fh="1" dt="EUROPE" disabled="disabled" value="0" onclick="isSystemBefore(this, \'' + dataOne + '\')"/>系统';
                                    } else html += '<input type="radio" id="is_sys_fullEuropeBefore' + match_id + '" name="is_sys_fullEuropeBefore' + match_id + '"fh="1" dt="EUROPE" value="0" onclick="isSystemBefore(this, \'' + dataOne + '\')"/>系统';
                                    html += '<br />';
                                    html += '<input type="radio" id="is_people_fullEuropeBefore' + match_id + '" name="is_people_fullEuropeBefore' + match_id + '"fh="1" dt="EUROPE" value="1" onclick="isSystemBefore(this, \'' + dataOne + '\')" checked="checked"/>人工';
                                } else {
                                    html += '&nbsp;';
                                    html += '<br />';
                                    html += '&nbsp;';
                                }

                                html += '</td>';
                                html += '</tr>';
                                html += '</table>';

                                // gridObjMatchBefore.getColCells(colIndex)[rowIndex].innerHTML = html;
                            }
                        }
                    },function () {
                        Feng.error("queryMatchOddsByMatchId请求挂了```")
                    });
                    ajx.setData(sendData);
                    ajx.start();
                    return html
                }
            },
            {title: '亚', field: 'fullAsianBefore', align: 'center', valign: 'middle', sortable: false,formatter:
                function (value, row) {
                    var match_id = row.match_id;
                    var html = '';
                    var resultData;
                    var fixtrue_win = '&nbsp;';
                    var fixtrue_lost = '&nbsp;';
                    var handicap_value = '';
                    var bet_status = '-1';
                    var ctl_method = '-1';
                    var ctl = row.CTL_METHOD;
                    var sendData = {
                        'match_id': match_id,//赛事ID
                        'bet_type': 'ASIAN',//亚盘
                        'odds_phase': '1,2',//赔率阶段 1:早盘   2:今日盘  3:滚球盘
                        'match_phase': '0'
                    }

                    var ajx = new $ax(Feng.ctxPath + "/Operate/queryMatchOddsByMatchId", function (data) {
                        if (!Feng.isEmpty(data.data)) {
                            resultData = JSON.parse(data.data[0].FIXTURE_ODDS);
                            if (!Feng.isEmpty(resultData)) {
                                fixtrue_win = resultData.w;
                                fixtrue_lost = resultData.l;
                                handicap_value = parseFloat(resultData.h) > 0 ? '+' + parseFloat(resultData.h) : parseFloat(resultData.h);
                                bet_status = data.data[0].bet_status;
                                ctl_method = data.data[0].CTL_METHOD;

                                var dataOne = new Array();
                                dataOne.push(data.data[0].match_group_id);
                                dataOne.push(data.data[0].ft_match_id);
                                dataOne.push(data.data[0].odds_phase);
                                dataOne.push(handicap_value);

                                html += '<table border="1" width="100%" height="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;border-width:0px; border-style:;">';
                                html += '<tr>';
                                html += '<td colspan="2">' + handicap_value + '&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">' + fixtrue_win + '</font></td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">' + fixtrue_lost + '</font></td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td colspan="2">&nbsp;</td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td>';

                                if (parseInt(ctl_method) == 0) {//投注状态: 0 正常    1 封盘
                                    html += '<input type="radio" id="is_sys_fullAsianBefore' + match_id + '" name="is_sys_fullAsianBefore' + match_id + '"fh="1" dt="ASIAN" value="0" onclick="isSystemBefore(this, \'' + dataOne + '\')" checked="checked"/>系统';
                                    html += '<br />';
                                    html += '<input type="radio" id="is_people_fullAsianBefore' + match_id + '" name="is_people_fullAsianBefore' + match_id + '"fh="1" dt="ASIAN" value="1" onclick="isSystemBefore(this, \'' + dataOne + '\')"/>人工';
                                } else if (parseInt(ctl_method) == 1) {
                                    if (ctl == 1) {
                                        html += '<input type="radio" id="is_sys_fullAsianBefore' + match_id + '" name="is_sys_fullAsianBefore' + match_id + '"fh="1" dt="ASIAN" disabled="disabled" value="0" onclick="isSystemBefore(this, \'' + dataOne + '\')"/>系统';
                                    } else html += '<input type="radio" id="is_sys_fullAsianBefore' + match_id + '" name="is_sys_fullAsianBefore' + match_id + '"fh="1" dt="ASIAN" value="0" onclick="isSystemBefore(this, \'' + dataOne + '\')"/>系统';
                                    html += '<br />';
                                    html += '<input type="radio" id="is_people_fullAsianBefore' + match_id + '" name="is_people_fullAsianBefore' + match_id + '"fh="1" dt="ASIAN" value="1" onclick="isSystemBefore(this, \'' + dataOne + '\')" checked="checked"/>人工';
                                } else {
                                    html += '&nbsp;';
                                    html += '<br />';
                                    html += '&nbsp;';
                                }

                                html += '</td>';
                                html += '</tr>';
                                html += '</table>';

                                // gridObjMatchBefore.getColCells(colIndex)[rowIndex].innerHTML = html;
                            }
                        }
                    },function () {
                        Feng.error("queryMatchOddsByMatchId请求挂了```")
                    });
                    ajx.setData(sendData);
                    ajx.start();
                    return html
                }
            },
            {title: '大小', field: 'fullBigsmallBefore', align: 'center', valign: 'middle', sortable: false,formatter:
                function (value, row) {
                    var match_id = row.match_id;
                    var html = '';
                    var resultData;
                    var fixtrue_big = '&nbsp;';
                    var fixtrue_small = '&nbsp;';
                    var handicap_value = '';
                    var big_handicap_value = '';
                    var small_handicap_value = '';
                    var bet_status = '-1';
                    var ctl_method = '-1';
                    var ctl = row.CTL_METHOD;
                    var sendData = {
                        'match_id': match_id,//赛事ID
                        'bet_type': 'BIGSMALL',//大小
                        'odds_phase': '1,2',//赔率阶段 1:早盘   2:今日盘  3:滚球盘
                        'match_phase': '0'
                    }

                    var ajx = new $ax(Feng.ctxPath + "/Operate/queryMatchOddsByMatchId", function (data) {
                        if (!Feng.isEmpty(data.data)) {
                            resultData = JSON.parse(data.data[0].FIXTURE_ODDS);
                            if (!Feng.isEmpty(resultData)) {
                                fixtrue_big = resultData.b;
                                fixtrue_small = resultData.s;
                                handicap_value = parseFloat(resultData.h);
                                big_handicap_value = '大' + handicap_value;
                                small_handicap_value = '小' + handicap_value;
                                bet_status = data.data[0].bet_status;
                                ctl_method = data.data[0].CTL_METHOD;

                                var dataOne = new Array();
                                dataOne.push(data.data[0].match_group_id);
                                dataOne.push(data.data[0].ft_match_id);
                                dataOne.push(data.data[0].odds_phase);
                                dataOne.push(handicap_value);

                                html += '<table border="1" width="100%" height="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;border-width:0px; border-style:;">';
                                html += '<tr>';
                                html += '<td colspan="2">' + big_handicap_value + '&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">' + fixtrue_big + '</font></td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td colspan="2">' + small_handicap_value + '&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">' + fixtrue_small + '</font></td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td colspan="2">&nbsp;</td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td>';

                                if (parseInt(ctl_method) == 0) {//投注状态: 0 正常    1 封盘
                                    html += '<input type="radio" id="is_sys_fullBigsmallBefore' + match_id + '" name="is_sys_fullBigsmallBefore' + match_id + '"fh="1" dt="BIGSMALL" value="0" onclick="isSystemBefore(this, \'' + dataOne + '\')" checked="checked"/>系统';
                                    html += '<br />';
                                    html += '<input type="radio" id="is_people_fullBigsmallBefore' + match_id + '" name="is_sys_fullBigsmallBefore' + match_id + '"fh="1" dt="BIGSMALL" value="1" onclick="isSystemBefore(this, \'' + dataOne + '\')"/>人工';
                                } else if (parseInt(ctl_method) == 1) {
                                    if (ctl == 1) {
                                        html += '<input type="radio" id="is_sys_fullBigsmallBefore' + match_id + '" name="is_sys_fullBigsmallBefore' + match_id + '"fh="1" dt="BIGSMALL" disabled="disabled" value="0" onclick="isSystemBefore(this, \'' + dataOne + '\')"/>系统';
                                    } else html += '<input type="radio" id="is_sys_fullBigsmallBefore' + match_id + '" name="is_sys_fullBigsmallBefore' + match_id + '"fh="1" dt="BIGSMALL" value="0" onclick="isSystemBefore(this, \'' + dataOne + '\')"/>系统';
                                    html += '<br />';
                                    html += '<input type="radio" id="is_people_fullBigsmallBefore' + match_id + '" name="is_people_fullBigsmallBefore' + match_id + '"fh="1" dt="BIGSMALL" value="1" onclick="isSystemBefore(this, \'' + dataOne + '\')" checked="checked"/>人工';
                                } else {
                                    html += '&nbsp;';
                                    html += '<br />';
                                    html += '&nbsp;';
                                }
                                html += '</td>';
                                html += '</tr>';
                                html += '</table>';

                                // gridObjMatchBefore.getColCells(colIndex)[rowIndex].innerHTML = html;
                            }
                        }
                    },function () {
                        Feng.error("queryMatchOddsByMatchId请求挂了```")
                    });
                    ajx.setData(sendData);
                    ajx.start();
                    return html
                }
            },
            {title: '欧', field: 'halfEuropeBefore', align: 'center', valign: 'middle', sortable: false,formatter:
                function (value, row) {
                    var match_id = row.match_id;
                    var html = '';
                    var resultData;
                    var fixtrue_win = '&nbsp;';
                    var fixtrue_lost = '&nbsp;';
                    var fixtrue_draw = '&nbsp;';
                    var bet_status = '-1';
                    var ctl_method = '-1';
                    var ctl = row.CTL_METHOD;
                    var sendData = {
                        'match_id': match_id,//赛事ID
                        'bet_type': 'EUROPE',//欧盘
                        'odds_phase': '1,2',//赔率阶段 1:早盘   2:今日盘  3:滚球盘
                        'match_phase': '1'//0:全场  1:上半场
                    }

                    var ajx = new $ax(Feng.ctxPath + "/Operate/queryMatchOddsByMatchId", function (data) {
                        if (!Feng.isEmpty(data.data)) {
                            resultData = data.data[0].FH_FIXTURE_ODDS;
                            if (!Feng.isEmpty(resultData)) {
                                resultData = JSON.parse(data.data[0].FH_FIXTURE_ODDS);
                                fixtrue_win = resultData.w;
                                fixtrue_lost = resultData.l;
                                fixtrue_draw = resultData.d;
                                bet_status = data.data[0].fh_bet_status;
                                ctl_method = data.data[0].fh_ctl_method;

                                var dataOne = new Array();
                                dataOne.push(data.data[0].match_group_id);
                                dataOne.push(data.data[0].ft_match_id);
                                dataOne.push(data.data[0].odds_phase);

                                html += '<table border="1" width="100%" height="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;border-width:0px; border-style:;">';
                                html += '<tr>';
                                html += '<td colspan="2"><font color="red">' + fixtrue_win + '</font></td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td colspan="2"><font color="red">' + fixtrue_lost + '</font></td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td colspan="2"><font color="red">' + fixtrue_draw + '</font></td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td>';

                                if (parseInt(ctl_method) == 0) {//投注状态: 0 正常    1 封盘
                                    html += '<input type="radio" id="is_sys_halfEuropeBefore' + match_id + '" name="is_sys_halfEuropeBefore' + match_id + '"fh="0" dt="EUROPE" value="0" onclick="isSystemBefore(this, \'' + dataOne + '\')" checked="checked"/>系统';
                                    html += '<br />';
                                    html += '<input type="radio" id="is_people_halfEuropeBefore' + match_id + '" name="is_sys_halfEuropeBefore' + match_id + '"fh="0" dt="EUROPE" value="1" onclick="isSystemBefore(this, \'' + dataOne + '\')"/>人工';
                                } else if (parseInt(ctl_method) == 1) {
                                    if (ctl == 1) {
                                        html += '<input type="radio" id="is_sys_halfEuropeBefore' + match_id + '" name="is_sys_halfEuropeBefore' + match_id + '"fh="0" dt="EUROPE" value="0" disabled="disabled" onclick="isSystemBefore(this, \'' + dataOne + '\')"/>系统';

                                    } else html += '<input type="radio" id="is_sys_halfEuropeBefore' + match_id + '" name="is_sys_halfEuropeBefore' + match_id + '"fh="0" dt="EUROPE" value="0" onclick="isSystemBefore(this, \'' + dataOne + '\')"/>系统';
                                    html += '<br />';
                                    html += '<input type="radio" id="is_people_halfEuropeBefore' + match_id + '" name="is_people_halfEuropeBefore' + match_id + '"fh="0" dt="EUROPE" value="1" onclick="isSystemBefore(this, \'' + dataOne + '\')" checked="checked"/>人工';
                                } else {
                                    html += '&nbsp;';
                                    html += '<br />';
                                    html += '&nbsp;';
                                }

                                html += '</td>';
                                html += '</tr>';
                                html += '</table>';

                                // gridObjMatchBefore.getColCells(colIndex)[rowIndex].innerHTML = html;
                            }
                        }
                    },function () {
                        Feng.error("queryMatchOddsByMatchId请求挂了```")
                    });
                    ajx.setData(sendData);
                    ajx.start();
                    return html
                }
            },
            {title: '亚', field: 'halfAsianBefore', align: 'center', valign: 'middle', sortable: false,formatter:
                function (value, row) {
                    var match_id = row.match_id;
                    var html = '';
                    var resultData;
                    var fixtrue_win = '&nbsp;';
                    var fixtrue_lost = '&nbsp;';
                    var handicap_value = '';
                    var bet_status = '-1';
                    var ctl_method = '-1';
                    var ctl = row.CTL_METHOD;
                    var sendData = {
                        'match_id': match_id,//赛事ID
                        'bet_type': 'ASIAN',//亚盘
                        'odds_phase': '1,2',//赔率阶段 1:早盘   2:今日盘  3:滚球盘
                        'match_phase': '1'//0:全场  1:上半场
                    }

                    var ajx = new $ax(Feng.ctxPath + "/Operate/queryMatchOddsByMatchId", function (data) {
                        if (!Feng.isEmpty(data.data)) {
                            resultData = data.data[0].FH_FIXTURE_ODDS;
                            if (!Feng.isEmpty(resultData)) {
                                resultData = JSON.parse(data.data[0].FH_FIXTURE_ODDS);
                                fixtrue_win = resultData.w;
                                fixtrue_lost = resultData.l;
                                handicap_value = parseFloat(resultData.h) > 0 ? '+' + parseFloat(resultData.h) : parseFloat(resultData.h);
                                bet_status = data.data[0].fh_bet_status;
                                ctl_method = data.data[0].fh_ctl_method;

                                var dataOne = new Array();
                                dataOne.push(data.data[0].match_group_id);
                                dataOne.push(data.data[0].ft_match_id);
                                dataOne.push(data.data[0].odds_phase);
                                dataOne.push(handicap_value);

                                html += '<table border="1" width="100%" height="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;border-width:0px; border-style:;">';
                                html += '<tr>';
                                html += '<td colspan="2">' + handicap_value + '&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">' + fixtrue_win + '</font></td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">' + fixtrue_lost + '</font></td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td colspan="2">&nbsp;</td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td>';

                                if (parseInt(ctl_method) == 0) {//投注状态: 0 正常    1 封盘
                                    html += '<input type="radio" id="is_sys_halfAsianBefore' + match_id + '" name="is_sys_halfAsianBefore' + match_id + '"fh="0" dt="ASIAN" value="0" onclick="isSystemBefore(this, \'' + dataOne + '\')" checked="checked"/>系统';
                                    html += '<br />';
                                    html += '<input type="radio" id="is_people_halfAsianBefore' + match_id + '" name="is_sys_halfAsianBefore' + match_id + '"fh="0" dt="ASIAN" value="1" onclick="isSystemBefore(this, \'' + dataOne + '\')"/>人工';
                                } else if (parseInt(ctl_method) == 1) {
                                    if (ctl == 1) {
                                        html += '<input type="radio" disabled="disabled" id="is_sys_halfAsianBefore' + match_id + '" name="is_sys_halfAsianBefore' + match_id + '"fh="0" dt="ASIAN" value="0" onclick="isSystemBefore(this, \'' + dataOne + '\')"/>系统';
                                    }
                                    html += '<input type="radio" id="is_sys_halfAsianBefore' + match_id + '" name="is_sys_halfAsianBefore' + match_id + '"fh="0" dt="ASIAN" value="0" onclick="isSystemBefore(this, \'' + dataOne + '\')"/>系统';
                                    html += '<br />';
                                    html += '<input type="radio" id="is_people_halfAsianBefore' + match_id + '" name="is_people_halfAsianBefore' + match_id + '"fh="0" dt="ASIAN" value="1" onclick="isSystemBefore(this, \'' + dataOne + '\')" checked="checked"/>人工';
                                } else {
                                    html += '&nbsp;';
                                    html += '<br />';
                                    html += '&nbsp;';
                                }

                                html += '</td>';
                                html += '</tr>';
                                html += '</table>';

                                // gridObjMatchBefore.getColCells(colIndex)[rowIndex].innerHTML = html;
                            }
                        }
                    },function () {
                        Feng.error("queryMatchOddsByMatchId请求挂了```")
                    });
                    ajx.setData(sendData);
                    ajx.start();
                    return html
                }
            },
            {title: '大小', field: 'halfBigsmallBefore', align: 'center', valign: 'middle', sortable: false,formatter:
                function (value, row) {
                    var match_id = row.match_id;
                    var html = '';
                    var resultData;
                    var fixtrue_big = '&nbsp;';
                    var fixtrue_small = '&nbsp;';
                    var handicap_value = '';
                    var big_handicap_value = '';
                    var small_handicap_value = '';
                    var bet_status = '-1';
                    var ctl_method = '-1';
                    var ctl = row.CTL_METHOD;
                    var sendData = {
                        'match_id': match_id,//赛事ID
                        'bet_type': 'BIGSMALL',//大小
                        'odds_phase': '1,2',//赔率阶段 1:早盘   2:今日盘  3:滚球盘
                        'match_phase': '1'//0:全场  1:上半场
                    }

                    var ajx = new $ax(Feng.ctxPath + "/Operate/queryMatchOddsByMatchId", function (data) {
                        if (!Feng.isEmpty(data.data)) {
                            resultData = data.data[0].FH_FIXTURE_ODDS;
                            if (!Feng.isEmpty(resultData)) {
                                resultData = JSON.parse(data.data[0].FH_FIXTURE_ODDS);
                                fixtrue_big = resultData.b;
                                fixtrue_small = resultData.s;
                                handicap_value = parseFloat(resultData.h);
                                big_handicap_value = '大' + handicap_value;
                                small_handicap_value = '小' + handicap_value;
                                bet_status = data.data[0].fh_bet_status;
                                ctl_method = data.data[0].fh_ctl_method;

                                var dataOne = new Array();
                                dataOne.push(data.data[0].match_group_id);
                                dataOne.push(data.data[0].ft_match_id);
                                dataOne.push(data.data[0].odds_phase);
                                dataOne.push(handicap_value);

                                html += '<table border="1" width="100%" height="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;border-width:0px; border-style:;">';
                                html += '<tr>';
                                html += '<td colspan="2">' + big_handicap_value + '&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">' + fixtrue_big + '</font></td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td colspan="2">' + small_handicap_value + '&nbsp;&nbsp;&nbsp;&nbsp;<font color="red">' + fixtrue_small + '</font></td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td colspan="2">&nbsp;</td>';
                                html += '</tr>';
                                html += '<tr>';
                                html += '<td>';

                                if (parseInt(ctl_method) == 0) {//投注状态: 0 正常    1 封盘
                                    html += '<input type="radio" id="is_sys_halfBigsmallBefore' + match_id + '" name="is_sys_halfBigsmallBefore' + match_id + '"fh="0" dt="BIGSMALL" value="0" onclick="isSystemBefore(this, \'' + dataOne + '\')" checked="checked"/>系统';
                                    html += '<br />';
                                    html += '<input type="radio" id="is_people_halfBigsmallBefore' + match_id + '" name="is_sys_halfBigsmallBefore' + match_id + '"fh="0" dt="BIGSMALL" value="1" onclick="isSystemBefore(this, \'' + dataOne + '\')"/>人工';
                                } else if (parseInt(ctl_method) == 1) {
                                    if (ctl == 1) {
                                        html += '<input type="radio" disabled="disabled" id="is_sys_halfBigsmallBefore' + match_id + '" name="is_sys_halfBigsmallBefore' + match_id + '"fh="0" dt="BIGSMALL" value="0" onclick="isSystemBefore(this, \'' + dataOne + '\')"/>系统';
                                    } else html += '<input type="radio" id="is_sys_halfBigsmallBefore' + match_id + '" name="is_sys_halfBigsmallBefore' + match_id + '"fh="0" dt="BIGSMALL" value="0" onclick="isSystemBefore(this, \'' + dataOne + '\')"/>系统';
                                    html += '<br />';
                                    html += '<input type="radio" id="is_people_halfBigsmallBefore' + match_id + '" name="is_people_halfBigsmallBefore' + match_id + '"fh="0" dt="BIGSMALL" value="1" onclick="isSystemBefore(this, \'' + dataOne + '\')" checked="checked"/>人工';
                                } else {
                                    html += '&nbsp;';
                                    html += '<br />';
                                    html += '&nbsp;';
                                }

                                html += '</td>';
                                html += '</tr>';
                                html += '</table>';
                                // gridObjMatchBefore.getColCells(colIndex)[rowIndex].innerHTML = html;
                            }
                        }
                    },function () {
                        Feng.error("queryMatchOddsByMatchId请求挂了```")
                    });
                    ajx.setData(sendData);
                    ajx.start();
                    return html
                }
            }
        ]
    ]
    return columns;
};


//刷新时间
Operate.refreshTime = function (_this) {
    var time = parseInt(_this.value);
    clearInterval(timer);
    if (time != 0) {
        timer = setInterval(function () {
            var queryData = {};

            queryData['begin_time'] = $("#begin_time").val();
            queryData['end_time'] = $("#end_time").val();
            queryData['match_id'] = $("#match_id").val();
            queryData["is_live"]=1; //滚球
            Operate.table.server_init(queryData);
            queryData["is_live"]=0; //赛前
            Operate1.table = table.server_init(queryData);
        }, time);
    };
};

/**
 * 此操作查询时间段所有的盘口
 * @param op_cl 1/关闭 0/打开
 */
Operate.alertMsg = function (op_cl) {
    Feng.confirm("确定对时间段内的比赛执行该操作吗?",function () {
        var sendData = {
            'begin_time': $('#begin_time').val(),
            'end_time': $('#end_time').val(),
            'league_id': $('#league_id').val(),
            'match_status': $('#match_status').val(),
            'ctl_method': op_cl
        };
        var ajx = new $ax(Feng.ctxPath + "/Operate/openCloseMatch", function (data) {
            if (data.msg_code == 1) {
                var x = parseInt(data.msg_total);
                var y = parseInt(data.msg_sum);
                var z = y - x;
                var str = "操作完成!成功: " + x + "  失败: " + z;
                Feng.success(str);
                setTimeout(function () {
                    var queryData = {};

                    queryData['begin_time'] = $("#begin_time").val();
                    queryData['end_time'] = $("#end_time").val();
                    queryData['match_id'] = $("#match_id").val();
                    queryData["is_live"]=1; //滚球
                    Operate.table.refresh({query: queryData});
                    queryData["is_live"]=0; //赛前
                    Operate1.table.refresh({query: queryData});
                },2000);
            }

        }, function () {
            Feng.error("openCloseMatch请求挂了```")
        });
        ajx.setData(sendData);
        ajx.start();
    });



}

/**
 * 滚球盘开关
 */
 function betOperateLive(rowIndex, operate) {
    var obj = $('#' + Operate.id).bootstrapTable('getData')[rowIndex]; //取得行记录数据
    var operateMsg = "";
    var ctl_method = "";
    var sendData = null;
    var match_id = obj.match_id;
    var match_group_id = obj.match_group_id;
    var odds_type = obj.odds_type;
    if (operate == "0") {//停止投注
        operateMsg = "确定要停止投注吗？";
        ctl_method = 1;

    } else if (operate == "1") {//开放投注
        operateMsg = "确定要开放投注吗？";
        ctl_method = 0;
    }

    sendData = {
        'match_id': match_id,
        'odds_type': odds_type,
        'match_group_id': match_group_id,
        'ctl_method': ctl_method
    };

    Feng.confirm(operateMsg, function () {
        var ajx = new $ax(Feng.ctxPath + "/Operate/matchBetOperate", function (data) {
            if (data.res_code == '1') {
                Feng.success(data.res_msg);
                var queryData = {};
                queryData['begin_time'] = $("#begin_time").val();
                queryData['end_time'] = $("#end_time").val();
                queryData['match_id'] = $("#match_id").val();
                queryData["is_live"] = 1; //滚球
                Operate.table.refresh({query: queryData});
            } else {
                Feng.error(data.res_msg);
                return;
            }
        }, function () {
            Feng.error("matchBetOperate请求挂了```")
        });
        ajx.setData(sendData);
        ajx.start();
    });
}

/**
 * 滚球 全场、半场亚、欧、大小赔率  人工、系统 处理函数
 * @param _this
 * @param dataOne
 */
function isSystemLive(_this, dataOne) {
    var id = _this.id;
    var fh = document.getElementById(id).attributes.fh.value;
    var dt = document.getElementById(id).attributes.dt.value;
    var sendData = null;
    var ctl_method = _this.value;
    var dataTwp = dataOne.split(",");

    sendData = {
        'match_group_id': dataTwp[0],
        'ft_match_id': dataTwp[1],
        'odds_phase': dataTwp[2],
        'fh': fh,
        'ctl_method': ctl_method,
        'odds_type': dt
    };
    if (dt != "EUROPE") {
        sendData.handicap_value = dataTwp[3];
    }

    Feng.confirm("确定要执行该操作吗？", function () {
        var ajx = new $ax(Feng.ctxPath + "/Operate/matchOddsBetOperate", function (data) {
            if (data.res_code == '1') {
                Feng.success(data.res_msg);
                var queryData = {};
                queryData['begin_time'] = $("#begin_time").val();
                queryData['end_time'] = $("#end_time").val();
                queryData['match_id'] = $("#match_id").val();
                queryData["is_live"] = 1; //滚球
                Operate.table.refresh({query: queryData});
            } else {
                Feng.error(data.res_msg);
                return;
            }
        }, function () {
            Feng.error("matchOddsBetOperate请求挂了```")
        });
        ajx.setData(sendData);
        ajx.start();
    });
}

/**
 * 赛前投注操作
 *
 /* 投注状态:  0 正常    1 滚球封盘   2赛前封盘  3滚球和赛前都封盘  7结束投注（终结状态）
 二进制比特位开关解释如下
 00  赛前和滚球都可投注
 01  赛前可投注，滚球不可投注
 10  赛前不可投注，滚球可投注
 11  赛前和滚球都不可投注
 111 结束投注（终结状态）
 */

function betOperateBefore(rowIndex, operate) {
    var operateMsg = "";
    var obj = $('#' + Operate1.id).bootstrapTable('getData')[rowIndex]; //取得行记录数据
    var sendData = null;
    var match_id = obj.match_id;
    var match_group_id = obj.match_group_id;
    var ctl_method = "";
    if (operate == "0") {//停止投注
        operateMsg = "确定要停止投注吗？";
        ctl_method = 1

    } else if (operate == "1") {//开放投注
        operateMsg = "确定要开放投注吗？";
        ctl_method = 0

    }

    sendData = {
        'match_id': match_id,
        'match_group_id': match_group_id,
        'ctl_method': ctl_method
    };
    Feng.confirm(operateMsg, function () {
        var ajx = new $ax(Feng.ctxPath + "/Operate/matchBetOperate", function (data) {
            if (data.res_code == '1') {
                Feng.success(data.res_msg);
                var queryData = {};
                queryData['begin_time'] = $("#begin_time").val();
                queryData['end_time'] = $("#end_time").val();
                queryData['match_id'] = $("#match_id").val();
                queryData["is_live"] = 0; //赛前
                Operate1.table.refresh({query: queryData});
            } else {
                Feng.error(data.res_msg);
                return;
            }
        }, function () {
            Feng.error("matchBetOperate请求挂了```")
        });
        ajx.setData(sendData);
        ajx.start();
    });
}

/**
 * 赛前 全场、半场亚、欧、大小赔率  人工、系统 处理函数
 * @param _this
 * @param dataOne
 */
function isSystemBefore(_this, dataOne) {
    var thisObj = _this;
    var name = _this.name;
    var sendData = null;
    var ctl_method = _this.value;

    var id = _this.id;
    var fh = document.getElementById(id).attributes.fh.value;
    var dt = document.getElementById(id).attributes.dt.value;
    var dataTwp = dataOne.split(",");
    sendData = {
        'match_group_id': dataTwp[0],
        'ft_match_id': dataTwp[1],
        'odds_phase': dataTwp[2],
        'fh': fh,
        'ctl_method': ctl_method,
        'odds_type': dt
    };
    if (dt != "EUROPE") {
        sendData.handicap_value = dataTwp[3];
    }
    console.log("ddd" + sendData)

    Feng.confirm("确定要执行该操作吗？", function () {
        var ajx = new $ax(Feng.ctxPath + "/Operate/matchOddsBetOperate", function (data) {
            if (data.res_code == '1') {
                Feng.success(data.res_msg);
                var queryData = {};
                queryData['begin_time'] = $("#begin_time").val();
                queryData['end_time'] = $("#end_time").val();
                queryData['match_id'] = $("#match_id").val();
                queryData["is_live"] = 0; //赛前
                Operate1.table.refresh({query: queryData});
            } else {
                Feng.error(data.res_msg);
                return;
            }
        }, function () {
            Feng.error("matchOddsBetOperate请求挂了```")
        });
        ajx.setData(sendData);
        ajx.start();
    });

    var radioArr = $("input[name=" + name + "]");
    if (parseInt(thisObj.value) == parseInt(radioArr[0].value)) {
        radioArr[1].checked = true;
    } else if (parseInt(thisObj.value) == parseInt(radioArr[1].value)) {
        radioArr[0].checked = true;
    }
}


//比赛状态下拉列表
function queryMatchStatusSelect(id, isAllElement) {
    var begin_time = $("#begin_time").val();
    var end_time = $("#end_time").val();
    var match_id = $("#match_id").val();


    var sendData = {
        'begin_time': begin_time,
        'end_time': end_time,
        'match_id': match_id
    };

    var ajx = new $ax(Feng.ctxPath + "/Operate/queryMatchStatusSelect", function (data) {
        var resultData = data.data;
        var matchStatusList = $("#" + id);

        matchStatusList.empty();//清空select下拉框
        if (isAllElement == "true") {
            var tmpOptOne = $("<option>");
            tmpOptOne.val("");
            tmpOptOne.text("全部");
            matchStatusList.append(tmpOptOne);
        }

        for (var i = 0; i < resultData.length; i++) {
            var tmpOpt = $("<option>");
            tmpOpt.val(resultData[i].status_code);
            tmpOpt.text(resultData[i].status_name);
            matchStatusList.append(tmpOpt);
        }
    }, function () {
        Feng.error("queryMatchStatusSelect请求挂了```")
    });
    ajx.setData(sendData);
    ajx.start();
}

//联赛下拉列表
function queryLeagueSelect(id, isAllElement) {
    var begin_time = $("#begin_time").val();
    var end_time = $("#end_time").val();
    var match_id = $("#match_id").val();


    var sendData = {
        'begin_time': begin_time,
        'end_time': end_time,
        'match_id': match_id
    };
    var ajx = new $ax(Feng.ctxPath + "/Operate/queryLeagueSelect", function (data) {
        var resultData = data.data;
        var leagueList = $("#" + id);

        leagueList.empty();//清空select下拉框
        if (isAllElement == "true") {
            var tmpOptOne = $("<option>");
            tmpOptOne.val("");
            tmpOptOne.text("全部");
            leagueList.append(tmpOptOne);
        }

        for (var i = 0; i < resultData.length; i++) {
            var tmpOpt = $("<option>");
            tmpOpt.val(resultData[i].league_id);
            tmpOpt.text(resultData[i].league_name);
            leagueList.append(tmpOpt);
        }
    }, function () {
        Feng.error("queryLeagueSelect请求挂了```")
    });
    ajx.setData(sendData);
    ajx.start();
}

/**
 * 搜索
 */
Operate.queryMatchesInfoOperateData = function () {
    var queryData = {};

    queryData['begin_time'] = $("#begin_time").val();
    queryData['end_time'] = $("#end_time").val();
    queryData['match_id'] = $("#match_id").val();
    queryData["is_live"]=1; //滚球
    Operate.table.server_init(queryData);
    queryData["is_live"]=0; //赛前
    Operate1.table.server_init(queryData);

    queryMatchStatusSelect("match_status", "true");//比赛状态下拉列表
    queryLeagueSelect("league_id", "true");//联赛下拉列表

}

$(function () {
    var begin_time = $("#begin_time").val();
    var end_time = $("#end_time").val();
    var queryData = {};
    queryData["begin_time"]=begin_time;
    queryData["end_time"]=end_time;

    queryData["is_live"]=1; //滚球
    var defaultColunms = Operate.initColumn();
    var table = new BSTable(Operate.id, "/Operate/queryMatchesInfoOperateData", defaultColunms);
    Operate.table = table.server_init(queryData);

    queryData["is_live"]=0; //赛前
    var defaultColunms = Operate1.initColumn1();
    var table = new BSTable(Operate1.id, "/Operate/queryMatchesInfoOperateData", defaultColunms);
    Operate1.table = table.server_init(queryData);

    queryMatchStatusSelect("match_status", "true");//比赛状态下拉列表
    queryLeagueSelect("league_id", "true");//联赛下拉列表
});

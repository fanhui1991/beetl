/**
 * 大单监控
 */
var Single = {
    id: "SingleTable",	//表格id
    seItem: null,		//选中的条目
    table: null,
    layerIndex: -1
};


var play_dict = {"70102":"全场亚盘","70112":"半场亚盘",
    "70104":"全场大小","70114":"半场大小",
    "70133":"全场单双","70143":"半场单双",
    "70101":"全场欧盘","70111":"半场欧盘",
    "70150":"半场/全场","70170":"双重机会",
    "70103":"全场波胆","70113":"半场波胆",
    "70105":"全场总进球","70115":"半场总进球",
    "70130":"全场角球","70140":"半场角球"
}
var inplay_dict = {0:"滚球",1:"赛前"};

/**
 * 初始化表格的列
 */
Single.initColumn = function () {
    var columns = [
        {field: 'selectItem', radio: true},
        {title: 'id', field: 'id', visible: false, align: 'center', valign: 'middle',width:'50px'},
        {title: '用户账号', field: 'user_name', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row, index) {
                return '<a href=\"'+Feng.ctxPath+'/Single/toUserOrderMonitorPage?user_id='+row.user_id+'&begin_time='+$("#begin_time").val()
                    +'&end_time='+$("#end_time").val()+'&min_item_money_f='+$("#min_item_money").val()
                    +'&min_prize_money_f='+$("#min_prize_money").val()+'\">'+row.user_name+'</a>';
        }},
        {title: '投注时间', field: 'pay_time', align: 'center', valign: 'middle', sortable: false},
        {title: '对阵ID', field: 'match_id', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row, index) {
                return '<a href=\"'+Feng.ctxPath+'/Single/toUserOrderMonitorPage?match_id='+row.match_id+'&begin_time='+$("#begin_time").val()
                    +'&end_time='+$("#end_time").val()+'&min_item_money_f='+$("#min_item_money").val()
                    +'&min_prize_money_f='+$("#min_prize_money").val()+'\">'+row.match_id+'</a>';
            }},
        {title: '球类', field: 'sport_type', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row, index) {
                var sport_type = row.sport_type;
                if(sport_type == 'S'){
                    sport_type = '足球'
                }
                if(sport_type == 'BB'){
                    sport_type = '篮球'
                }
                if(sport_type == 'TN'){
                    sport_type = '网球'
                }
                if(sport_type == 'ES'){
                    sport_type = '电竞'
                }
                return sport_type;
            }
        },
        {title: '联赛', field: 'league_name', align: 'center', valign: 'middle', sortable: false},
        {title: '比赛时间', field: 'match_time', align: 'center', valign: 'middle', sortable: false},
        {title: '比赛', field: 'match_info', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var is_fh_finish = row.is_fh_finish;
                var home_team_name = row.home_team_name;
                var away_team_name = row.away_team_name;
                var is_finish = row.is_finish;
                var play_type = row.play_type;
                var match_info = "";
                if(play_type == 10){
                    if(is_fh_finish == 1){
                        match_info = home_team_name +" <font color=red> " + row.fh_home_score +" : " + row.fh_away_score +" </font> "+ away_team_name ;
                    }else{
                        match_info = home_team_name +" vs " + away_team_name;
                    }
                }else if(play_type == 20){
                    if(is_finish == 1){
                        match_info = home_team_name +" <font color=red> " + row.home_score +" : " + row.away_score +" </font> "+ away_team_name;
                    }else{
                        match_info = home_team_name +" vs " + away_team_name;
                    }
                }
                return match_info;
            }
        },
        {title: '类型', field: 'bets_type', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var play_id = row.play_id;
                var is_inplay = row.is_inplay;
                if(Feng.isEmpty(play_id)){
                    return row.bets_type;
                }
                return play_dict[play_id]+" - "+inplay_dict[is_inplay]
            }
        },
        {title: '下单时比分', field: 'score', align: 'center', valign: 'middle', sortable: false},
        {title: '投注项', field: 'bets_info', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                if(!Feng.isEmpty(row.bets_type)){
                    return;
                }else {
                    return row.CLIENT_PROPERTIES;
                }
            }
        },
        {title: '投注金额', field: 'item_money', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var item_money_b = row.bj;
                var item_money_c = row.cj;
                var item_money_1 = row.item_money_1;
                return ((item_money_b+item_money_c+item_money_1)+'').replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,');
            }
        },
        {title: '返奖金额', field: 'prize_money', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var prize_money = row.prize_money;
                var item_money_b = row.bj;
                var item_money_c = row.cj;
                var item_money_1 = row.item_money_1;
                var item_status = row.item_status;

                if(item_status == '-10'||item_status == '210'){
                    return ((item_money_b+item_money_c+item_money_1)+'').replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,');
                }else{
                    return (prize_money+'').replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,');
                }
                return 0;
            }},
        {title: '账户类别', field: 'item_cost', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var item_money_b = row.bj;
                var item_money_c = row.cj;
                var item_money_1 = row.item_money_1;
                if (item_money_b > 0 && item_money_c == 0){
                    return "本金"
                }else if(item_money_c > 0 && item_money_b ==0){
                    return "彩金"
                }else if(item_money_1 > 0 && item_money_c == 0 && item_money_b ==0){
                    return "全部"
                }else if(item_money_b >0 && item_money_c > 0){
                    return "本+彩"
                }
            }
        },
        {title: '订单状态', field: 'item_status', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var html = "";
                var status = row.item_status;
                var desc = row.desc;

                switch(status){
                    case 0: html = "初始状态 ";break;
                    case 10: html = "待开奖";break;
                    case -5: html = "<font color='red'>投注失败(退款中)";break;
                    case -10: html = "<font color='red'>投注失败 "+" ("+ desc +") ";break;
                    case -100: html = "输";break;
                    case 100: html = "结算中 ";break;
                    case 110: html = "赢  ";break;
                    case 120: html = "走盘 ";break;
                    case 130: html = "输半 ";break;
                    case 140: html = "赢半 ";break;
                    case 200: html = "退款中 ";break;
                    case 210: html = "已退款 (关盘)";break;
                    default: html = status;break;
                }
                return html;
            }
        },
        {title: '订单状态', field: 'itemStatus', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var itemStatu  = row.item_status;
                if(itemStatu == 10 ||(itemStatu == 0)){
                    var html = "";
                    var updateItemStatus = $("#updateItemStatus").val();
                    if(!Feng.isEmpty(updateItemStatus)){
                        html += '<a href="#" onclick="Single.click_item_status(\''+row.item_id+'\');">取消</a>';
                    }
                    return html;
                }
            }
        },
        {title: '投注明细', field: 'item_id', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                return '<a onclick=Single.click_item_id(\''+row.item_id+'\')> 详情</a>';
            }
        }
    ]
    return columns;
};

/**
 * 取消订单
 * @param item_id
 */
Single.click_item_status = function (item_id) {
    var sendData = {
        'item_id': item_id
    };
    Feng.confirm('是否取消该订单？', function () {
        var ajax = new $ax(Feng.ctxPath + "/Single/updateItemStatus", function (data) {
            if (data.res_code == '1') {
                Feng.success(data.res_msg);
            } else {
                Feng.error(data.res_msg);
            };
            var queryData = {};
            queryData['min_item_money_min'] = $("#min_item_money_min").val();
            queryData['min_item_money_max'] = $("#min_item_money_max").val();
            queryData['begin_time'] = $("#begin_time").val();
            queryData['end_time'] = $("#end_time").val();
            queryData['bets_type'] = $("#bets_type").val();
            queryData['sport_type'] = $("#sport_type").val();
            queryData['min_prize_money_min'] = $("#min_prize_money_min").val();
            queryData['min_prize_money_max'] = $("#min_prize_money_max").val();
            queryData['user_name'] = $("#user_name").val();
            queryData['match_id'] = $("#match_id").val();
            queryData['play_id'] = $("#play_id").val();
            queryData['channel_code'] = $("#channel_code").val();
            queryData['item_type'] = $("#item_type").val();
            Single.table.refresh({query: queryData});
        }, function () {
            Feng.error("请求失败了!");
        });
        ajax.setData(sendData);
        ajax.start();
    });
};

//跳转到比赛详情
Single.click_item_id=function (item_id) {
    Feng.layerOpen("投注详情","80%","80%","/Single/toOrderMonitorDetailPage/"+item_id)
};


/**
 * 搜索
 */
Single.queryMatchOrderList = function () {
    var queryData = {};

    queryData['min_item_money_min'] = $("#min_item_money_min").val();
    queryData['min_item_money_max'] = $("#min_item_money_max").val();
    queryData['begin_time'] = $("#begin_time").val();
    queryData['end_time'] = $("#end_time").val();
    queryData['bets_type'] = $("#bets_type").val();
    queryData['sport_type'] = $("#sport_type").val();
    queryData['min_prize_money_min'] = $("#min_prize_money_min").val();
    queryData['min_prize_money_max'] = $("#min_prize_money_max").val();
    queryData['user_name'] = $("#user_name").val();
    queryData['match_id'] = $("#match_id").val();
    queryData['play_id'] = $("#play_id").val();
    queryData['channel_code'] = $("#channel_code").val();
    queryData['item_type'] = $("#item_type").val();

    Single.table.server_init(queryData);
}

$(function () {
    var defaultColunms = Single.initColumn();
    var table = new BSTable(Single.id, "/Single/queryOrderItemList", defaultColunms);
    var queryData = {};

    queryData['begin_time'] = $("#begin_time").val();
    queryData['end_time'] = $("#end_time").val();

    Single.table = table.server_init(queryData);
});

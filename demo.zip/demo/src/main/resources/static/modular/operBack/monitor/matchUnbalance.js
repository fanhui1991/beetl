/**
 * 单场失衡监控
 */
var Unbalan = {
    id: "UnbalanTable",	//表格id
    seItem: null,		//选中的条目
    table: null,
    layerIndex: -1
};

var playId = {"70102":"全场亚盘","70112":"半场亚盘","70104":"全场大小","70114":"半场大小","70133":"全场单双","70143":"半场单双","70101":"全场欧盘","70111":"半场欧盘"}

/**
 * 初始化表格的列
 */
Unbalan.initColumn = function () {
    var columns = [
        {field: 'selectItem', radio: true},
        {title: 'id', field: 'id', visible: false, align: 'center', valign: 'middle',width:'50px'},
        {title: '赛事ID', field: 'MATCH_ID', align: 'center', valign: 'middle', sortable: false},
        {title: '赛事状态', field: 'ref_status', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                if (row.REF_STATUS ==1){
                    return "已开售"
                }else if (row.REF_STATUS ==0){
                    return "未开售"
                }
                return row.REF_STATUS
            }
        },
        {title: '开赛时间', field: 'MATCH_DATE', align: 'center', valign: 'middle', sortable: false},
        {title: '对阵信息', field: 'team', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                return row.HOME_TEAM_NAME +" VS "+row.AWAY_TEAM_NAME
            }
        },
        {title: '失衡盘口', field: 'un_Handicap', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var play_id = (row.PLAY_ID).split(",");
                var un_handicap="";
                for (var i=0;i<play_id.length;i++){
                    un_handicap += playId[play_id[i]]+"<br>"
                }
                return un_handicap
            }
        },
        {title: '盘口受注情况', field: 'handicap', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var play_id = (row.PLAY_ID).split(",");
                var hand = (row.HANDICAP).split(","); //盘口
                var h = (row.s).split(","); //判断失衡盘口 a/欧盘胜 b/平 c/负  其他<0 上盘失衡else下盘失衡
                var s = (row.s_ITEM_MONEY).split(","); //上盘
                var p = (row.p_ITEM_MONEY).split(","); //平局 欧盘独有
                var x = (row.x_ITEM_MONEY).split(","); //下盘
                var home = row.HOME_TEAM_NAME;
                var AWAY = row.AWAY_TEAM_NAME;
                var hicap="";
                var team="";
                var money="";
                for (var i=0;i<h.length;i++){
                    if(h[i] == "a" || h[i] > 0){
                        if(play_id[i] =="70104" || play_id[i] =="70114"){
                            team = "大"+hand[i];
                        }else if(play_id[i] =="70133" || play_id[i] =="70143"){
                            team = "单";
                        }else if(play_id[i] =="70101" || play_id[i] =="70111") {
                            team = home;
                        } else{ //亚盘
                            if((hand[i])[0] == "-"){
                                team = home+hand[i];
                            }else{
                                team = home +"+"+ hand[i];
                            }
                        }
                    }else if(h[i] == "b"){
                        team = "平";
                    }else if(h[i] == "c" || h[i] < 0){
                        if(play_id[i] =="70104" || play_id[i] =="70114"){
                            team = "小"+hand[i];
                        }else if(play_id[i] =="70133" || play_id[i] =="70143"){
                            team = "双";
                        }else if(play_id[i] =="70101" || play_id[i] =="70111") {
                            team = AWAY;
                        }else{ //亚盘
                            if((hand[i])[0] == "-"){
                                team = AWAY+"+"+hand[i].replace("-","");
                            }else{
                                team = AWAY+"-"+hand[i];
                            }
                        }
                    }
                    //受注金额详情
                    if(play_id[i] =="70104" || play_id[i] =="70114") { //大小球
                        if (!Feng.isEmpty(s[i])) {
                            money = "大:" + s[i];
                        } else {
                            money = "大:0";
                        }

                        if (!Feng.isEmpty(x[i])) {
                            money += " 小:" + x[i];
                        } else {
                            money += " 小:0";
                        }
                    }

                    if(play_id[i] =="70133" || play_id[i] =="70143") { //单双
                        if (!Feng.isEmpty(s[i])) {
                            money = "单:" + s[i];
                        } else {
                            money = "单:0";
                        }

                        if (!Feng.isEmpty(x[i])) {
                            money += " 双:" + x[i];
                        } else {
                            money += " 双:0";
                        }
                    }

                    if(play_id[i] =="70101" || play_id[i] =="70111") { //欧盘
                        if (!Feng.isEmpty(s[i])) {
                            money = "胜:" + s[i];
                        } else {
                            money = "胜:0";
                        }

                        if (!Feng.isEmpty(p[i])) {
                            money += " 平:" + p[i];
                        } else {
                            money += " 平:0";
                        }


                        if (!Feng.isEmpty(x[i])) {
                            money += " 负:" + x[i];
                        } else {
                            money += " 负:0";
                        }
                    }

                    if(play_id[i] =="70102" || play_id[i] =="70112") { //亚盘
                        if (!Feng.isEmpty(s[i])) {
                            money = "上盘:" + s[i];
                        } else {
                            money = "上盘:0";
                        }

                        if (!Feng.isEmpty(x[i])) {
                            money += " 下盘:" + x[i];
                        } else {
                            money += " 下盘:0";
                        }
                    }
                    hicap += team+"  "+money+"<br>"
                }
                return hicap
            }
        },
        {title: '失衡金额', field: 'un_money', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var s_money = (row.s_money).split(",");
                var unMoney="";
                for(var i=0;i<s_money.length;i++){
                    if(!Feng.isEmpty(s_money[i])){
                        unMoney += s_money[i] +"<br>"
                    }else{
                        unMoney += "0<br>"
                    }
                }
                return unMoney;
            }
        },
        {title: '失衡率', field: 'rate', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                if(row.rate ==null){
                    return '100%'
                }
                var s_rate = (row.rate).split(",");
                var rate="";
                for(var i=0;i<s_rate.length;i++){
                    if(!Feng.isEmpty(s_rate[i])){
                        rate += s_rate[i] +"%<br>"
                    }else{
                        rate += "0%<br>"
                    }
                }
                return rate;
            }
        }
    ]
    return columns;
};



/**
 * 搜索
 */
Unbalan.queryMatchUnbalanceList = function () {
    var queryData = {};

    queryData['matchId'] = $("#matchId").val();
    queryData['match_time_start'] = $("#match_time_start").val();
    queryData['match_time_end'] = $("#match_time_end").val();
    queryData['is_sale'] = $("#is_sale").val();
    queryData['unba_start_rate'] = $("#unba_start_rate").val();
    queryData['unba_end_rate'] = $("#unba_end_rate").val();
    queryData['unba_start_money'] = $("#unba_start_money").val();
    queryData['unba_end_money'] = $("#unba_end_money").val();
    queryData['is_agent'] = $("#is_agent").val();
    queryData['sport_type'] = $("#sport_type").val();

    Unbalan.table.server_init(queryData);
}

$(function () {
    var defaultColunms = Unbalan.initColumn();
    var table = new BSTable(Unbalan.id, "/Unbalan/queryMatchUnbalanceList", defaultColunms);
    var queryData = {};

    queryData['match_time_start'] = $("#match_time_start").val();
    queryData['match_time_end'] = $("#match_time_end").val();
    Unbalan.table = table.server_init(queryData);
});

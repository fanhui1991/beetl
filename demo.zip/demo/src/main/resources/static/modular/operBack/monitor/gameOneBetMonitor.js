/**
 * 单场受注监控
 */
var Monitor = {
    id: "MonitorTable",	//表格id
    seItem: null,		//选中的条目
    table: null,
    layerIndex: -1
};

/**
 * 初始化表格的列
 */
Monitor.initColumn = function () {
    var columns = [
        {field: 'selectItem', radio: true},
        {title: 'id', field: 'id', visible: false, align: 'center', valign: 'middle',width:'50px'},
        {title: '赛事ID', field: 'match_id', align: 'center', valign: 'middle', sortable: false},
        {title: '赛事状态', field: 'ref_status', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var refStatus = row.ref_status;
                if(refStatus==1){
                    return "已开售"
                }else if(refStatus==0){
                    return "未开售"
                }
                return refStatus
            }
        },
        {title: '开赛时间', field: 'match_time', align: 'center', valign: 'middle', sortable: false},
        {title: '对阵信息', field: 'team', align: 'center', valign: 'middle', sortable: false},
        {title: '未结量', field: 'wei_j', align: 'center', valign: 'middle', sortable: false},
        {title: '总受注量', field: 'item_money', align: 'center', valign: 'middle', sortable: false},
        {title: '总返奖量', field: 'prize_money', align: 'center', valign: 'middle', sortable: false},
        {title: '返奖率', field: 'rate', align: 'center', valign: 'middle', sortable: false}
    ]
    return columns;
};



/**
 * 搜索
 */
Monitor.queryBetMonitorList = function () {
    var queryData = {};

    queryData['matchId'] = $("#matchId").val();
    queryData['match_time_start'] = $("#match_time_start").val();
    queryData['match_time_end'] = $("#match_time_end").val();
    queryData['is_sale'] = $("#is_sale").val();
    queryData['prize_start_rate'] = $("#prize_start_rate").val();
    queryData['prize_end_rate'] = $("#prize_end_rate").val();
    queryData['is_agent'] = $("#is_agent").val();
    queryData['sport_type'] = $("#sport_type").val();

    Monitor.table.server_init(queryData);
}

$(function () {
    var defaultColunms = Monitor.initColumn();
    var table = new BSTable(Monitor.id, "/Monitor/queryBetMonitorList", defaultColunms);
    var queryData = {};

    queryData['match_time_start'] = $("#match_time_start").val();
    queryData['match_time_end'] = $("#match_time_end").val();
    Monitor.table = table.server_init(queryData);
});

/**
 * 返奖率监控
 */
var Profit = {
    id: "ProfitTable",	//表格id
    seItem: null,		//选中的条目
    table: null,
    layerIndex: -1
};

/**
 * 初始化表格的列
 */
Profit.initColumn = function () {
    var columns = [
        {field: 'selectItem', radio: true},
        {title: 'id', field: 'id', visible: false, align: 'center', valign: 'middle',width:'50px'},
        {title: '用户账号', field: 'user_acct', align: 'center', valign: 'middle', sortable: false},
        {title: '投注金额', field: 'item_money', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var item_money = row.item_money;
                if(item_money){
                    return (item_money+'').replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,');
                }
                return 0;
            }
        },
        {title: '返奖金额', field: 'prize_money', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var prize_money = row.prize_money;
                if(prize_money){
                    return (prize_money+'').replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,');
                }
                return 0;
            }
        },
        {title: '盈亏金额', field: 'yingkui_money', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var yingkui_money = row.yingkui_money;
                if(yingkui_money){
                    return (yingkui_money+'').replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,');
                }
                return 0;
            }
        },
        {title: '返奖率', field: 'profit_rate', align: 'center', valign: 'middle', sortable: false},
        {title: '投注历史', field: 'bet_history', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                return '<a href=\"'+Feng.ctxPath+'/Single/toUserOrderMonitorPage?user_id='+row.user_id+'&begin_time='+$("#begin_time").val()
                    +'&end_time='+$("#end_time").val()+'\">详情</a>';
            }
        }
    ]
    return columns;
};


/**
 * 搜索
 */
Profit.queryUserProfitList = function () {
    var queryData = {};

    queryData['user_acct'] = $("#user_acct").val();
    queryData['begin_time'] = $("#begin_time").val();
    queryData['end_time'] = $("#end_time").val();
    queryData['tz_start_money'] = $("#tz_start_money").val();
    queryData['tz_end_money'] = $("#tz_end_money").val();
    queryData['fj_start_money'] = $("#fj_start_money").val();
    queryData['fj_end_money'] = $("#fj_end_money").val();
    queryData['min_profit_rate'] = $("#min_profit_rate").val();

    Profit.table.server_init(queryData);
}

$(function () {
    var defaultColunms = Profit.initColumn();
    var table = new BSTable(Profit.id, "/Profit/queryUserProfitList", defaultColunms);
    var queryData = {};
    queryData['begin_time'] = $("#begin_time").val();
    queryData['end_time'] = $("#end_time").val();
    Profit.table = table.server_init(queryData);
});

/**
 * 行情管理
 */
var Match = {
    id: "MatchTable",	//表格id
    seItem: null,		//选中的条目
    table: null,
    layerIndex: -1
};

/**
 * 初始化表格的列
 */
Match.initColumn = function () {
    var columns = [
        {field: 'selectItem', radio: false},
        {title: 'id', field: 'id', visible: false, align: 'center', valign: 'middle',width:'50px'},
        {title: '比赛时间', field: 'MATCH_DATE', align: 'center', valign: 'middle', sortable: false},
        {title: '对阵ID', field: 'MATCH_ID', align: 'center', valign: 'middle', sortable: false},
        {title: '联赛', field: 'LEAGUE_NAME', align: 'center', valign: 'middle', sortable: false},
        {title: '球类', field: 'SPORT_NAME_CN', align: 'center', valign: 'middle', sortable: false},
        {title: '对阵', field: 'TEAM_NAMES', align: 'center', valign: 'middle', sortable: false},
        {title: '状态', field: 'MARKET_TYPE', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                if(row.MARKET_TYPE == '1' || row.MARKET_TYPE == '2'){
                    return "赛前";
                }else{
                    return "滚球";
                }
            }
        },
        {title: '开售', field: 'ref_status', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var REF_STATUS = "否";
                var status = row.STATUS;
                if(status == 0){
                    if(row.REF_STATUS == '1'){
                        REF_STATUS = "是";
                    }
                    return "<a href='#' title='点击切换开售状态' onclick='Match.propertySwith(\"match_is_in_sale\",\""+row.REF_STATUS+
                        "\",\""+row.MATCH_GROUP_ID+"\",\""+row.MATCH_ID+"\",\"开售状态\", \""+row.TEAM_NAMES+"\", \""+ row.IS_TOP +"\")' >"+REF_STATUS+"</a>";
                }else{
                    var REF_STATUS = "<font color='#999'>否</font>";
                    if(row.REF_STATUS == '1'){
                        REF_STATUS = "<font color='#999'>是</font>";
                    }
                    return REF_STATUS;
                }
            }
        },
        {title: '首页展示', field: 'IS_INDEX', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var IS_INDEX = "否";
                var status = row.STATUS;
                if(status == 0) {
                    if (row.IS_INDEX == '1') {
                        IS_INDEX = "是";
                    }
                    return "<a href='#' title='点击切换首页展示状态' onclick='Match.propertySwith(\"match_is_index\",\"" + row.IS_INDEX +
                        "\",\"" + row.MATCH_GROUP_ID + "\",\"" + row.MATCH_ID + "\",\"首页展示状态\", \"" + row.TEAM_NAMES +
                        "\", \"" + row.IS_TOP + "\")' >" + IS_INDEX + "</a>";
                }else{
                    var IS_INDEX = "<font color='#999'>否</font>";
                    if(row.IS_INDEX == '1'){
                        IS_INDEX = "<font color='#999'>是</font>";

                    }
                    return IS_INDEX;
                }
            }
        },
        {title: '置顶', field: 'IS_TOP', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var is_top = "否";
                var status = row.STATUS;
                if(status == 0){
                    if(row.IS_TOP == '1'){
                        is_top = "是";
                    }

                    if(row.IS_INDEX == '1' && row.REF_STATUS == '1'){
                        return "<a href='#' title='点击切换首页展示状态' onclick='Match.propertySwith(\"match_is_top\",\""+row.IS_TOP+
                            "\",\""+row.MATCH_GROUP_ID+"\",\""+row.MATCH_ID+"\",\"置顶\", \""+row.TEAM_NAMES+
                            "\", \""+ row.IS_TOP +"\")' >"+is_top+"</a>";
                    }else{
                        return "<a href='#' title='请先设为首页展示和开售状态,再置顶' onclick='Match.keep_top_alert()'>否</a>";
                    }
                }else{
                    var is_top = "<font color='#999'>否</font>";
                    if(row.IS_TOP == '1'){
                        is_top = "<font color='#999'>是</font>";
                    }
                    return is_top;
                }
            }
        },
        {title: '标记异常', field: 'IS_EXCEPT', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row, index) {
                var MANUAL_STATUS = row.MANUAL_STATUS;
                var rowIndex = index;
                if(MANUAL_STATUS == 1){
                    return '<a href="#" onclick="Match.manualExpert('+rowIndex +');">否</a>';
                }else{
                    return '<a href="#" onclick="Match.manualExpert('+rowIndex +');">是</a>';
                }
            }
        }
    ]
    return columns;
};

Match.keep_top_alert = function (){
    Feng.info("请先设为首页展示和开售状态,再置顶");
}

Match.propertySwith = function (propertyName, propertyValue, MATCH_GROUP_ID, MATCH_ID, propertyNameDisplay, team_names, is_top){
    if(propertyValue == '1'){
        propertyValue = '否';
    }else{
        propertyValue = '是';
    }
    if(propertyName == 'match_is_in_sale'){
        if(propertyValue == '否' && is_top == '是'){
            Feng.info("当前比赛已被置顶,无法取消开售.");
            return;
        }

        var sendData = {
            'match_group_id':MATCH_GROUP_ID,
            'match_id':MATCH_ID,
            'match_is_in_sale':propertyValue
        };
    }else if(propertyName == 'match_is_index'){
        if(propertyValue == '否' && is_top == '是'){
            Feng.info("当前比赛已被置顶,无法取消首页展示.");
            return;
        }
        var sendData = {
            'match_group_id':MATCH_GROUP_ID,
            'match_id':MATCH_ID,
            'match_is_index':propertyValue
        };
    }else if(propertyName == 'match_is_focus'){
        var sendData = {
            'match_group_id':MATCH_GROUP_ID,
            'match_id':MATCH_ID,
            'match_is_focus':propertyValue
        };
    }else if(propertyName == 'match_is_top'){
        var sendData = {
            'match_group_id':MATCH_GROUP_ID,
            'match_id':MATCH_ID,
            'match_is_top':propertyValue
        };
    }else{
        return;
    }

    var operateMsg = '确定要修改'+team_names+'的'+propertyNameDisplay+'为【'+propertyValue+'】吗?';
    Feng.confirm(operateMsg, function() {
       var ajx = new $ax(Feng.ctxPath + "/Match/switchOver", function (data) {
           Feng.success("success");
       }, function () {
           Feng.error("switchOver请求失败了")
       });
       ajx.setData(sendData);
       ajx.start();
   });
};


//修改订单异常状态
Match.manualExpert = function (rowIndex){
    var obj = $('#' + this.id).bootstrapTable('getData')[rowIndex];
    var TEAM_NAMES = obj.TEAM_NAMES;
    var exceType = obj.MANUAL_STATUS;
    var MATCH_ID = obj.MATCH_ID;
    if(exceType == 1){
        exceType = '是'
    }else{
        exceType = '否'
    }
    var sendData = {
        'MATCH_ID':MATCH_ID,
        'MATCH_GROUP_ID':obj.MATCH_GROUP_ID,
        'MANUAL_STATUS':obj.MANUAL_STATUS
    };

    Feng.confirm('确定要修改'+TEAM_NAMES+'的标记异常状态为【'+exceType+'】吗？',function() {
        var ajx = new $ax(Feng.ctxPath + "/Match/updateManualExcept", function (data) {
            if (data.res_code == '1') {
                Feng.success(data.res_msg);
                var queryData = {};
                queryData['league_name'] = $("#league_name").val();
                queryData['match_time_start'] = $("#match_time_start").val();
                queryData['match_time_end'] = $("#match_time_end").val();
                queryData['ref_status'] = $("#ref_status").val();
                queryData['is_index'] = $("#is_index").val();
                queryData['sport_type'] = $("#sport_type").val();
                queryData['market_type'] = $("#market_type").val();
                queryData['is_top'] = $("#is_top").val();
                queryData['isexception'] = $("#isexception").val();
                queryData['match_id'] = $("#match_id").val();
                Match.table.refresh({query: queryData});
            } else {
                Feng.error(data.res_msg);
            }
        }, function () {
            Feng.error("updateManualExcept请求失败了")
        });
        ajx.setData(sendData);
        ajx.start();
    });
};


/**
 * 批量开售
 */
Match.updateSellInBatch = function (status){
    var match_id_selected = [];
    var match_group_id_selected = [];
    var matchArray = $('#' + this.id).bootstrapTable('getSelections');
    if (matchArray.length == 0) {
        Feng.info("请至少选中一行!");
        return false;
    }

    for(var i=0; i<matchArray.length; i++){
        match_id_selected.push(matchArray[i].MATCH_ID);
        match_group_id_selected.push(matchArray[i].MATCH_GROUP_ID);
    }
    var sendData = {
        'match_id':match_id_selected,
        'match_group_id':match_group_id_selected,
        'match_status':status
    };
    var operateMsg = '确定要批量修改选中的比赛为【可开售】吗?';
    if(status == '否'){
        operateMsg = '确定要批量修改选中的比赛为【不可开售】吗?';
    }
    Feng.confirm(operateMsg, function(){
        var ajx = new $ax(Feng.ctxPath + "/Match/updateInBatch", function (data) {
            if (data.code == '1') {
                Feng.success("success");
                var queryData = {};
                queryData['league_name'] = $("#league_name").val();
                queryData['match_time_start'] = $("#match_time_start").val();
                queryData['match_time_end'] = $("#match_time_end").val();
                queryData['ref_status'] = $("#ref_status").val();
                queryData['is_index'] = $("#is_index").val();
                queryData['sport_type'] = $("#sport_type").val();
                queryData['market_type'] = $("#market_type").val();
                queryData['is_top'] = $("#is_top").val();
                queryData['isexception'] = $("#isexception").val();
                queryData['match_id'] = $("#match_id").val();
                Match.table.refresh({query: queryData});
            } else {
                Feng.error("error!数据已更新");
            }
        }, function () {
            Feng.error("updateInBatch请求失败了")
        });
        ajx.setData(sendData);
        ajx.start();
    });
};

/**
 * 批量首页展示
 * @param isIndex
 */
Match.updateIsIndexInBatch = function (isIndex){
    var match_id_selected = [];
    var match_group_id_selected = [];
    var matchArray = $('#' + this.id).bootstrapTable('getSelections');
    if (matchArray.length == 0) {
        Feng.info("请至少选中一行!");
        return false;
    }
    for(var i=0; i<matchArray.length; i++){
        match_id_selected.push(matchArray[i].MATCH_ID);
        match_group_id_selected.push(matchArray[i].MATCH_GROUP_ID);
    }
    sendData = {
        'match_id':match_id_selected,
        'match_group_id':match_group_id_selected,
        'match_is_index':isIndex
    };
    var operateMsg = '确定要批量修改选中的比赛为【首页展示】吗?';
    if(isIndex == '否'){
        operateMsg = '确定要批量修改选中的比赛为【不在首页展示】吗?';
    }
    Feng.confirm(operateMsg, function(){
        var ajx = new $ax(Feng.ctxPath + "/Match/updateInBatch", function (data) {
            if (data.code == '1') {
                Feng.success("success");
                var queryData = {};
                queryData['league_name'] = $("#league_name").val();
                queryData['match_time_start'] = $("#match_time_start").val();
                queryData['match_time_end'] = $("#match_time_end").val();
                queryData['ref_status'] = $("#ref_status").val();
                queryData['is_index'] = $("#is_index").val();
                queryData['sport_type'] = $("#sport_type").val();
                queryData['market_type'] = $("#market_type").val();
                queryData['is_top'] = $("#is_top").val();
                queryData['isexception'] = $("#isexception").val();
                queryData['match_id'] = $("#match_id").val();
                Match.table.refresh({query: queryData});
            } else {
                Feng.error("error!更新失败");
            }
        }, function () {
            Feng.error("updateInBatch请求失败了")
        });
        ajx.setData(sendData);
        ajx.start();
    });
};


/**
 * 搜索
 */
Match.queryMatches = function () {
    var queryData = {};

    queryData['league_name'] = $("#league_name").val();
    queryData['match_time_start'] = $("#match_time_start").val();
    queryData['match_time_end'] = $("#match_time_end").val();
    queryData['ref_status'] = $("#ref_status").val();
    queryData['is_index'] = $("#is_index").val();
    queryData['sport_type'] = $("#sport_type").val();
    queryData['market_type'] = $("#market_type").val();
    queryData['is_top'] = $("#is_top").val();
    queryData['isexception'] = $("#isexception").val();
    queryData['match_id'] = $("#match_id").val();

    Match.table.server_init(queryData);
};

$(function () {
    var defaultColunms = Match.initColumn();
    var table = new BSTable(Match.id, "/Match/queryMatchList", defaultColunms);
    var queryData = {};

    queryData['match_time_start'] = $("#match_time_start").val();
    queryData['match_time_end'] = $("#match_time_end").val();

    Match.table = table.server_init(queryData);
});

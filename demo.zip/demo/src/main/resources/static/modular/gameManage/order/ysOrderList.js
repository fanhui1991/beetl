/**
 * 订单管理
 */
var Order = {
    id: "OrderTable",	//表格id
    seItem: null,		//选中的条目
    table: null,
    layerIndex: -1
};


var play_dict = {"70102":"全场亚盘","70112":"半场亚盘",
    "70104":"全场大小","70114":"半场大小",
    "70133":"全场单双","70143":"半场单双",
    "70101":"全场欧盘","70111":"半场欧盘",
    "70150":"半场/全场","70170":"双重机会",
    "70103":"全场波胆","70113":"半场波胆",
    "70105":"全场总进球","70115":"半场总进球",
    "70130":"全场角球","70140":"半场角球"
}
var inplay_dict = {0:"滚球",1:"赛前"};

/**
 * 初始化表格的列
 */
Order.initColumn = function () {
    var columns = [
        {field: 'selectItem', radio: true},
        {title: 'id', field: 'id', visible: false, align: 'center', valign: 'middle',width:'50px'},
        {title: '用户帐号', field: 'user_name', align: 'center', valign: 'middle', sortable: false},
        {title: '投注时间', field: 'pay_time', align: 'center', valign: 'middle', sortable: false},
        {title: '联赛名称', field: 'league_name', align: 'center', valign: 'middle', sortable: false},
        {title: '球类', field: 'sport_type', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var sport = row.sport_type
                if(sport =='S'){
                    return '足球'
                }
                if(sport =='BB'){
                    return '篮球'
                }
                if(sport =='TN'){
                    return '网球'
                }
                if(sport =='ES'){
                    return '电竞'
                }
                return sport;
            }
        },
        {title: '对阵', field: 'match_info', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var is_fh_finish = row.is_fh_finish;
                var home_team_name = row.home_team_name;
                var away_team_name = row.away_team_name;
                var is_finish = row.is_finish;
                var play_type = row.play_type;
                var match_info = "";
                if(play_type == 10){
                    if(is_fh_finish == 1){
                        match_info = home_team_name +" <font color=red> " + row.fh_home_score +" : " + row.fh_away_score +" </font> "+ away_team_name ;
                    }else{
                        match_info = home_team_name +" vs " + away_team_name;
                    }
                }else if(play_type == 20){
                    if(is_finish == 1){
                        match_info = home_team_name +" <font color=red> " + row.home_score +" : " + row.away_score +" </font> "+ away_team_name;
                    }else{
                        match_info = home_team_name +" vs " + away_team_name;
                    }
                }
                return match_info;
            }
        },
        {title: '比赛时间', field: 'match_time', align: 'center', valign: 'middle', sortable: false},
        {title: '投注类型', field: 'bets_type', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var play_id = row.play_id;
                var is_inplay = row.is_inplay;
                if(Feng.isEmpty(play_id)){
                    return '<a onclick=Order.click_item_id(\''+row.item_id+'\')>' +row.bets_type+'</a>';
                }
                return '<a onclick=Order.click_item_id(\''+row.item_id+'\')>' +play_dict[play_id]+" - "+inplay_dict[is_inplay]+'</a>';
            }
        },
        {title: '投注事项', field: 'bets_info', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                if(!Feng.isEmpty(row.bets_type)){
                    return;
                }else {
                    return row.CLIENT_PROPERTIES;
                }
            }
        },
        {title: '下单比分', field: 'score', align: 'center', valign: 'middle', sortable: false},
        {title: '投注金额', field: 'item_money', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var item_money_b = row.bj;
                var item_money_c = row.cj;
                var item_money_1 = row.item_money_1;
                return ((item_money_b+item_money_c+item_money_1)+'').replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,');
            }
        },
        {title: '返奖金额', field: 'prize_money', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var prize_money = row.prize_money;
                var item_money_b = row.bj;
                var item_money_c = row.cj;
                var item_money_1 = row.item_money_1;
                var item_status = row.item_status;

                if(item_status == '-10'||item_status == '210'){
                    return ((item_money_b+item_money_c+item_money_1)+'').replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,');
                }else{
                    return (prize_money+'').replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,');
                }
                return 0;
            }
        },
        {title: '账户类别', field: 'item_cost', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var item_money_b = row.bj;
                var item_money_c = row.cj;
                var item_money_1 = row.item_money_1;
                if (item_money_b > 0 && item_money_c == 0){
                    return "本金"
                }else if(item_money_c > 0 && item_money_b ==0){
                    return "彩金"
                }else if(item_money_1 > 0 && item_money_c == 0 && item_money_b ==0){
                    return "全部"
                }else if(item_money_b >0 && item_money_c > 0){
                    return "本+彩"
                }
            }
        },
        {title: '订单状态', field: 'item_status', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row) {
                var desc = row.desc
                var item = row.item_id
                switch (row.item_status) {
                    case 0:
                        return "初始状态";
                        break;
                    case 10:
                        return "<a onclick='Order.SetPrize(\""+item+"\")'>待开奖</a>";
                        break;
                    case -5:
                        return "投注失败(退款中)";
                        break;
                    case -10:
                        return "投注失败" + " ("+desc+") ";
                        break;
                    case -100:
                        return "输";
                        break;
                    case 100:
                        return "结算中";
                        break;
                    case 110:
                        return "赢";
                        break;
                    case 120:
                        return "走盘";
                        break;
                    case 130:
                        return "输半";
                        break;
                    case 140:
                        return "赢半";
                        break;
                    case 200:
                        return "退款中";
                        break;
                    case 210:
                        return "已退款(关盘)";
                        break;
                }
            }
        },
        {title: '标记异常', field: 'exce_type', align: 'center', valign: 'middle', sortable: false,formatter:
            function (value, row, index) {
                var exce_type = row.abnormal_status;
                var rowIndex = index;
                if(exce_type == 1){
                    return '<a href="#" onclick="Order.cancelExpert('+rowIndex +');">是</a>';
                }else{
                    return '<a href="#" onclick="Order.cancelExpert('+rowIndex +');">否</a>';
                }
            }
        }
    ]
    return columns;
};

//手动开奖
Order.SetPrize = function (item_id) {
    var sendata={
        "item_id":item_id
    }
    Feng.confirm("是否手动对此单进行派奖？",function () {
        var ajx = new $ax(Feng.ctxPath+"/Order/QuerySetPrize",function (data) {
            Feng.success(data.res_msg);
            var queryData = {};

            queryData['item_id'] = $("#item_id").val();
            queryData['match_id'] = $("#match_id").val();
            queryData['beginTime'] = $("#beginTime").val();
            queryData['endTime'] = $("#endTime").val();
            queryData['match'] = $("#match").val();
            queryData['item_type'] = $("#item_type").val();
            queryData['payLeft'] = $("#payLeft").val();
            queryData['outRight'] = $("#outRight").val();
            queryData['ball'] = $("#ball").val();
            queryData['userId'] = $("#userId").val();
            queryData['channel_code'] = $("#channel_code").val();
            queryData['item_status'] = $("#item_status").val();
            Order.table.refresh({query: queryData});
        },function () {
            Feng.error("queryOrderItemDetail请求挂了```")
        });
        ajx.setData(sendata);
        ajx.start();
    })
}

//标记异常
Order.cancelExpert = function (rowIndex){
    var selected = $('#' + this.id).bootstrapTable('getData')[rowIndex]
    var home_team_name = selected.home_team_name;
    var away_team_name = selected.away_team_name;
    var exceType = selected.abnormal_status;
    if(exceType == 1){
        exceType = '否'
    }else{
        exceType = '是'
    }
    var sendData = {
        'user_acct':selected.user_name,
        'item_id':selected.item_id,
        'exce_type':selected.abnormal_status
    };

    Feng.confirm('确定要修改'+home_team_name+'VS'+away_team_name+'的标记异常状态为【'+exceType+'】吗？',function () {
        var ajx = new $ax(Feng.ctxPath + "/Order/updateExcept", function (data) {
            Feng.success(data.res_msg);
            var queryData = {};

            queryData['item_id'] = $("#item_id").val();
            queryData['matchId'] = $("#matchId").val();
            queryData['beginTime'] = $("#beginTime").val();
            queryData['endTime'] = $("#endTime").val();
            queryData['match'] = $("#match").val();
            queryData['item_type'] = $("#item_type").val();
            queryData['payLeft'] = $("#payLeft").val();
            queryData['outRight'] = $("#outRight").val();
            queryData['ball'] = $("#ball").val();
            queryData['userId'] = $("#userId").val();
            queryData['channel_code'] = $("#channel_code").val();
            queryData['item_status'] = $("#item_status").val();
            Order.table.refresh({query: queryData});
        }, function () {
            Feng.error("queryOrderItemDetail请求挂了```")
        });
        ajx.setData(sendData);
        ajx.start();
    })
}


//跳转到比赛详情
Order.click_item_id=function (item_id) {
    Feng.layerOpen("投注详情","80%","80%","/Single/toOrderMonitorDetailPage/"+item_id)
}

/**
 * 搜索
 */
Order.queryYsOrderList = function () {
    var queryData = {};

    queryData['item_id'] = $("#item_id").val();
    queryData['matchId'] = $("#matchId").val();
    queryData['beginTime'] = $("#beginTime").val();
    queryData['endTime'] = $("#endTime").val();
    queryData['match'] = $("#match").val();
    queryData['item_type'] = $("#item_type").val();
    queryData['payLeft'] = $("#payLeft").val();
    queryData['payRight'] = $("#payRight").val();
    queryData['outLeft'] = $("#outLeft").val();
    queryData['outRight'] = $("#outRight").val();
    queryData['ball'] = $("#ball").val();
    queryData['userId'] = $("#userId").val();
    queryData['channel_code'] = $("#channel_code").val();
    queryData['item_status'] = $("#item_status").val();

    Order.table.server_init(queryData);
}


$(function () {
    var defaultColunms = Order.initColumn();
    var table = new BSTable(Order.id, "/Order/queryYsOrderList", defaultColunms);
    var queryData = {};

    queryData['beginTime'] = $("#beginTime").val();
    queryData['endTime'] = $("#endTime").val();
    queryData['match'] = $("#match").val();
    queryData['item_type'] = $("#item_type").val();
    queryData['ball'] = $("#ball").val();
    queryData['channel_code'] = $("#channel_code").val();
    queryData['item_status'] = $("#item_status").val();

    Order.table = table.server_init(queryData);
});

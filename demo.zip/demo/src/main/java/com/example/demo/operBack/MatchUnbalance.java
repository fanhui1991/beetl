package com.example.demo.operBack;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 单场失衡监控
 */
@Controller
@RequestMapping("/Unbalan")
public class MatchUnbalance {

    private String PREFIX = "/operBack/monitor/";


    @RequestMapping("/toMatchUnbalance")
    public String betMonitorIndex(Model model) throws ParseException {
        Calendar calendar = Calendar.getInstance();
        Calendar calen = Calendar.getInstance();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String newTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calendar.getTime());
        String cDate = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calendar.getTime());
        Date d1 = df.parse(newTime);
        Date d2 = df.parse(cDate);
        String curDate1;
        String nextDate1;
        long diff = d1.getTime() - d2.getTime();
        if(diff < 0){
            calen.add(Calendar.DATE, -1);
            curDate1 = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calen.getTime());
            nextDate1 = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calendar.getTime());
        }else {
            calen.add(Calendar.DATE, 1);
            curDate1 = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calendar.getTime());
            nextDate1 = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calen.getTime());
        }
        model.addAttribute("curDate1",curDate1);
        model.addAttribute("nextDate1",nextDate1);
        return PREFIX+"matchUnbalance.html";
    }


    /**
     * queryBetMonitorList.do
     * 受注页面列表
     */
    @RequestMapping("/queryMatchUnbalanceList")
    @ResponseBody
    public HashMap<String,Object> queryMatchUnbalanceList(@RequestParam(required = false) HashMap map){
        HashMap<String,Object> resMap = new HashMap<String, Object>();
        List<HashMap<String,Object>> matchList = new ArrayList<HashMap<String,Object>>();
        HashMap<String,Object> res = new HashMap<String,Object>();
        res.put("AWAY_TEAM_NAME","尼日利亚");
        res.put("HANDICAP","0.5");
        res.put("HOME_TEAM_NAME","克罗地亚");
        res.put("MATCH_DATE","2018-06-17 03:00:00");
        res.put("MATCH_ID","6683605");
        res.put("PLAY_ID","70114");
        res.put("REF_STATUS",1);
        res.put("p_ITEM_MONEY","0.00");
        res.put("p_pei_money","");
        res.put("rate","106.67");
        res.put("s","53971.28");
        res.put("s_ITEM_MONEY","50597.00");
        res.put("s_money","53971.28");
        res.put("s_pei_money","53971.28");
        res.put("x_ITEM_MONEY","0.00");
        res.put("x_pei_money","0.00");
        matchList.add(res);
        resMap.put("total", 1);
        resMap.put("rows", matchList);
        return resMap;
    }
}

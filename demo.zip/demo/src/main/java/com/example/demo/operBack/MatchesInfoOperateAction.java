package com.example.demo.operBack;

import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.databind.util.JSONPObject;
import org.beetl.ext.fn.Json;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.*;

import static org.apache.coyote.http11.Constants.a;

/**
 * ClassName:MatchesInfoOperateAction <br/>
 * Function: 赛事资料操盘. <br/>
 * Reason:   赛事资料操盘. <br/>
 * zyl
 */
@Controller
@RequestMapping("/Operate")
public class MatchesInfoOperateAction {

    private String PREFIX = "/operBack/matchoper/";

    protected static final Logger LOG = LoggerFactory.getLogger(MatchesInfoOperateAction.class);


    /**
     * 默认时间格式
     **/
    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String DATE_FORMAT = "yyyy-MM-dd";


    /**
     * methodName: toMatchesInfoOperatePage
     * <p>
     * 跳转到赛事资料操盘页面.<br/>
     *
     * @param model
     * @return
     */
    @RequestMapping(value = "/toMatchesInfoOperatePage", method = {RequestMethod.GET,
            RequestMethod.POST})
    public String toMatchesInfoOperatePage(Model model) {
        Date date = new Date();
        SimpleDateFormat dateTimeFormat = new SimpleDateFormat(DATE_TIME_FORMAT);
        SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
        String beginTime = dateFormat.format(date) + " 00:00:00";
        String endTime = dateTimeFormat.format(date);
        model.addAttribute("begin_time", beginTime);
        model.addAttribute("end_time", endTime);
        return PREFIX+"matchesInfoOperate.html";
    }

    /**
     * methodName: queryMatchStatusSelect
     * <p>
     * 比赛状态下拉列表.<br/>
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/queryMatchStatusSelect", method = {RequestMethod.GET,
            RequestMethod.POST})
    public @ResponseBody
    Map<String, Object> queryMatchStatusSelect(
            HttpServletRequest request, HttpServletResponse response) {
        Map<String, Object> params = new HashMap<String, Object>();
        List<Map<String, Object>> resultList = new ArrayList<Map<String, Object>>();
        Map<String, Object> allStatusMap = new HashMap<String, Object>();
        Map<String, Object> resultMap1 = new HashMap<String, Object>();
        Map<String, Object> resultMap2 = new HashMap<String, Object>();
        String begin_time = request.getParameter("begin_time");
        String end_time = request.getParameter("end_time");
        if (!StringUtils.isEmpty(begin_time)) {
            params.put("match_begin_time", begin_time);
        }
        if (!StringUtils.isEmpty(end_time)) {
            params.put("match_end_time", end_time);
        }

//        params.put("is_live", "1");
//        resultMap1 = footBallOptService.queryOptMatchStatus(params);
//        params.put("is_live", "0");
//        resultMap2 = footBallOptService.queryOptMatchStatus(params);
        allStatusMap.putAll(resultMap2);
        allStatusMap.putAll(resultMap1);

        for (Map.Entry<String, Object> e : allStatusMap.entrySet()) {
            HashMap tmpMap = new HashMap();
            tmpMap.put("status_code", e.getKey());
            tmpMap.put("status_name", e.getValue());
            resultList.add(tmpMap);
        }

        Map<String, Object> resMap = new HashMap<String, Object>();
        resMap.put("data", resultList);
        return resMap;
    }

    /**
     * methodName: queryLeagueSelect
     * <p>
     * 联赛下拉列表.<br/>
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/queryLeagueSelect", method = {RequestMethod.GET,
            RequestMethod.POST})
    public @ResponseBody
    Map<String, Object> queryLeagueSelect(
            HttpServletRequest request, HttpServletResponse response) {
        Map<String, Object> params = new HashMap<String, Object>();
        List<Map<String, Object>> resultList = new ArrayList<Map<String, Object>>();
        Map<String, Object> allLeagueMap = new HashMap<String, Object>();
        Map<String, Object> resultMap1 = new HashMap<String, Object>();
        Map<String, Object> resultMap2 = new HashMap<String, Object>();
        String begin_time = request.getParameter("begin_time");
        String end_time = request.getParameter("end_time");
        if (!StringUtils.isEmpty(begin_time)) {
            params.put("match_begin_time", begin_time);
        }
        if (!StringUtils.isEmpty(end_time)) {
            params.put("match_end_time", end_time);
        }

//        params.put("is_live", "1");
//        resultMap1 = footBallOptService.queryOptMatchLeagues(params);
//        params.put("is_live", "0");
//        resultMap2 = footBallOptService.queryOptMatchLeagues(params);
        allLeagueMap.putAll(resultMap2);
        allLeagueMap.putAll(resultMap1);

        for (Map.Entry<String, Object> e : allLeagueMap.entrySet()) {
            HashMap tmpMap = new HashMap();
            tmpMap.put("league_id", e.getKey());
            tmpMap.put("league_name", e.getValue());
            resultList.add(tmpMap);
        }

        Map<String, Object> resMap = new HashMap<String, Object>();
        resMap.put("data", resultList);
        return resMap;
    }

    /**
     * methodName: queryMatchesInfoOperateData
     * <p>
     * 查询赛事数据.<br/>
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/queryMatchesInfoOperateData", method = {RequestMethod.GET, RequestMethod.POST})
    public @ResponseBody
    Map<String, Object> queryMatchesInfoOperateData(HttpServletRequest request,
                                                    HttpServletResponse response) {
        Map<String, Object> resMap = new HashMap<String, Object>();

        List<Map<String, Object>> lstMap = new ArrayList<Map<String, Object>>();
        Map<String, Object> a = new HashMap<>();
        a.put("CTL_METHOD",0);
        a.put("RUN_TIME",0);
        a.put("away_goal_num",0);
        a.put("away_team_name","尼日利亚  (先开球)");
        a.put("bet_status",0);
        a.put("home_goal_num",0);
        a.put("home_team_name","克罗地亚  (先开球)");
        a.put("league_id",28168);
        a.put("league_name","2018年世界杯足球赛(在俄罗斯) - 哪支球队先开球");
        a.put("match_group_id","9bc49c98-dfd7-4a48-a023-3efb68d3014d");
        a.put("match_id","6683727");
        a.put("match_time","06-17 02:55:00");
        a.put("status_id",1);
        a.put("status_name","未开始");
        lstMap.add(a);
        resMap.put("total", 1);
        resMap.put("rows", lstMap);
        return resMap;
    }

    /**
     * methodName: queryMatchOddsByMatchId
     * <p>
     * 根据match_id查询全场、半场 亚、欧、大小赔率.<br/>
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/queryMatchOddsByMatchId", method = {RequestMethod.GET,
            RequestMethod.POST})
    public @ResponseBody
    Map<String, Object> queryMatchOddsByMatchId(
            HttpServletRequest request, HttpServletResponse response) {
        Map<String, Object> resMap = new HashMap<String, Object>();
        String bet_type = request.getParameter("bet_type");//ASIAN:亚盘; BIGSMALL:大小盘; EUROPE:欧盘
        if("ASIAN".equals(bet_type)){
            List<Map<String, Object>> lstMap = new ArrayList<Map<String, Object>>();
            Map<String, Object> a = new HashMap<>();
            Map<String, Object> a1 = new HashMap<>();
            a1.put("w",0.96000);
            a1.put("h","0.0");
            a1.put("l",1.25000);
            a.put("CTL_METHOD",0);
            a.put("FH_CTL_METHOD",0);
            a.put("FIXTURE_ODDS",JSON.toJSONString(a1));
            a.put("ODDS_TYPE","ASIAN");
            a.put("bet_status",0);
            a.put("ft_match_id","6683727");
            a.put("match_sp_id",321770251);
            a.put("odds_phase",1);
            lstMap.add(a);

            resMap.put("data", lstMap);
        }
        if("EUROPE".equals(bet_type)){
            List<Map<String, Object>> lstMap = new ArrayList<Map<String, Object>>();
            Map<String, Object> a = new HashMap<>();
            Map<String, Object> a1 = new HashMap<>();
            a1.put("d",2.00000);
            a1.put("w",2.57000);
            a1.put("l",1.25000);
            Map<String, Object> a2 = new HashMap<>();
            a2.put("d",3.30000);
            a2.put("w",1.86000);
            a2.put("l",4.15000);
            a.put("CTL_METHOD",0);
            a.put("FH_BET_STATUS",0);
            a.put("FH_CTL_METHOD",0);
            a.put("FIXTURE_ODDS",JSON.toJSONString(a2));
            a.put("FH_FIXTURE_ODDS",JSON.toJSONString(a1));
            a.put("ODDS_TYPE","EUROPE");
            a.put("bet_status",0);
            a.put("fh_bet_status",0);
            a.put("ft_match_id","6683727");
            a.put("match_sp_id",321769840);
            a.put("odds_phase",1);
            lstMap.add(a);
            resMap.put("data", lstMap);
        }
        if("BIGSMALL".equals(bet_type)){
            List<Map<String, Object>> lstMap = new ArrayList<Map<String, Object>>();
            Map<String, Object> a = new HashMap<>();
            Map<String, Object> a1 = new HashMap<>();
            a1.put("b",0.79000);
            a1.put("s",1.12000);
            a1.put("h","0.75");
            Map<String, Object> a2 = new HashMap<>();
            a2.put("b",1.00000);
            a2.put("s",0.90000);
            a2.put("h","2.25");
            a.put("CTL_METHOD",0);
            a.put("FH_BET_STATUS",0);
            a.put("FH_CTL_METHOD",0);
            a.put("FIXTURE_ODDS",JSON.toJSONString(a2));
            a.put("FH_FIXTURE_ODDS",JSON.toJSONString(a1));
            a.put("ODDS_TYPE","BIGSMALL");
            a.put("bet_status",0);
            a.put("fh_bet_status",0);
            a.put("ft_match_id","6683605");
            a.put("match_sp_id",321769846);
            a.put("odds_phase",1);
            lstMap.add(a);
            resMap.put("data", lstMap);
        }
        return resMap;
    }

    /**
     * methodName: matchBetOperate
     * <p>
     * 赛事停止投注、开放投注操作和人工、系统 操作.<br/>
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/matchBetOperate", method = {RequestMethod.GET,
            RequestMethod.POST})
    public @ResponseBody
    Map<String, Object> matchBetOperate(
            HttpServletRequest request, HttpServletResponse response) {
        Map<String, Object> resMap = new HashMap<String, Object>();
        resMap.put("res_code", "1");
        resMap.put("res_msg", "操作成功！");
        return resMap;
    }

    @RequestMapping(value = "/openCloseMatch")
    public @ResponseBody
    Map<String, Object> openCloseMatch(HttpServletResponse response, HttpServletRequest request) {
        Map<String, Object> resMap = new HashMap<>();

        resMap.put("msg_code", 1);
        resMap.put("msg_sum", 2);
        resMap.put("msg_total", 2);
        return resMap;
    }




    /**
     * methodName: matchOddsBetOperate
     * <p>
     * 赛事赔率开关、人工、系统操作功能.<br/>
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/matchOddsBetOperate", method = {RequestMethod.GET,
            RequestMethod.POST})
    public @ResponseBody
    Map<String, Object> matchOddsBetOperate(
            HttpServletRequest request, HttpServletResponse response) {
        Map<String, Object> resMap = new HashMap<String, Object>();
        resMap.put("res_code", "1");
        resMap.put("res_msg", "操作成功");
        return resMap;
    }


}
  

package com.example.demo.game;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by zyl
 * 行情管理
 */
@Controller
@RequestMapping("/Match")
public class GameMatchAction {

    private String PREFIX = "/gameManage/match/";

    private final static Logger LOG = LoggerFactory.getLogger(GameMatchAction.class);


    @RequestMapping(value = "/toMatchListPage", method = { RequestMethod.GET,
            RequestMethod.POST })
    public ModelAndView toQueryLiveMatchesPage(HttpServletRequest request, HttpServletResponse response) throws ParseException {
        ModelAndView mav = new ModelAndView(PREFIX+"match.html");
        Calendar calendar = Calendar.getInstance();
        Calendar calen = Calendar.getInstance();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String newTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calendar.getTime());
        String cDate = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calendar.getTime());
        Date d1 = df.parse(newTime);
        Date d2 = df.parse(cDate);
        String curDate1;
        String nextDate1;
        long diff = d1.getTime() - d2.getTime();
        if(diff < 0){
            calen.add(Calendar.DATE, -1);
            curDate1 = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calen.getTime());
            nextDate1 = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calendar.getTime());
        }else {
            calen.add(Calendar.DATE, 1);
            curDate1 = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calendar.getTime());
            nextDate1 = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calen.getTime());
        }
        mav.addObject("curDate1", curDate1);
        mav.addObject("nextDate1", nextDate1);
        return mav;
    }

    @RequestMapping(value = "/queryMatchList", method = { RequestMethod.GET,
            RequestMethod.POST })
    public @ResponseBody
    HashMap queryMatchList(HttpServletRequest request, HttpServletResponse response) {
        HashMap<String,Object> rst = new HashMap<String,Object>();

        List<HashMap<String, Object>> rstMatchList = new ArrayList<HashMap<String, Object>>();
        HashMap<String, Object> map = new HashMap<>();
        map.put("IS_INDEX",0);
        map.put("IS_TOP",0);
        map.put("LEAGUE_NAME","2018年世界杯足球赛(在俄罗斯) - 哪支球队先开球");
        map.put("MANUAL_STATUS",1);
        map.put("MATCH_DATE","2018-06-16 17:55:00");
        map.put("MATCH_GROUP_ID","b7619711-6225-417d-a497-ade0099cbf7e");
        map.put("MATCH_ID","6683724");
        map.put("REF_STATUS",1);
        map.put("SPORT_NAME_CN","足球");
        map.put("STATUS",0);
        map.put("TEAM_NAMES","法国  (先开球)VS澳大利亚  (先开球)");
        rstMatchList.add(map);
        Integer totalCount = 1;
        rst.put("total", totalCount);
        rst.put("rows", rstMatchList);
        return rst;
    }

    @RequestMapping(value = "/switchOver", method = { RequestMethod.GET,
            RequestMethod.POST })
    public @ResponseBody
    HashMap<String, Object> propertySwitchOver(HttpServletRequest request, HttpServletResponse response){
        HashMap<String, Object> map = new HashMap<>();
        map.put("code", "SUCCESS");
        return map;
    }


    @RequestMapping(value = "/updateInBatch", method = { RequestMethod.GET,
            RequestMethod.POST })
    public @ResponseBody
    HashMap<String,Object> updateInBatch(HttpServletRequest request, HttpServletResponse response){
        Boolean result = true;
        HashMap<String, Object> map = new HashMap<>();
        map.put("code", result ? 1 : 0);
        return map;
    }


    //盘口异常标记
    @RequestMapping(value = "/updateManualExcept", method = {RequestMethod.GET,
            RequestMethod.POST})
    public @ResponseBody
    HashMap updateExcept(HttpServletRequest request, HttpServletResponse response) {
        HashMap<String, Object> res = new HashMap<String, Object>();
        res.put("res_code", "1");
        res.put("res_msg", "更变行情异常成功");
        return res;
    }

}


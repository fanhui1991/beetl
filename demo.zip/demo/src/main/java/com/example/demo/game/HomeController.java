package com.example.demo.game;

import com.example.demo.core.MenuNode;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by dell on 2018/6/16.
 */
@Controller
public class HomeController {

    @RequestMapping("/")
    public String index1(Model model) {

        List<MenuNode> menus = new ArrayList<MenuNode>();
        MenuNode gameParent = new MenuNode();
        gameParent.setId(1);
        gameParent.setParentId(0);
        gameParent.setName("Game系统");
        gameParent.setLevels(1);
        gameParent.setIsmenu(1);
        gameParent.setNum(1);
        menus.add(gameParent);

        MenuNode gameOrder = new MenuNode();
        gameOrder.setId(190);
        gameOrder.setParentId(1);
        gameOrder.setName("订单管理");
        gameOrder.setUrl("/Order/toYsOrderListPage");
        gameOrder.setLevels(2);
        gameOrder.setIsmenu(1);
        gameOrder.setNum(1);
        menus.add(gameOrder);

        MenuNode gameMatch = new MenuNode();
        gameMatch.setId(191);
        gameMatch.setParentId(1);
        gameMatch.setName("行情管理");
        gameMatch.setUrl("/Match/toMatchListPage");
        gameMatch.setLevels(2);
        gameMatch.setIsmenu(1);
        gameMatch.setNum(2);
        menus.add(gameMatch);

        MenuNode gameSingle = new MenuNode();
        gameSingle.setId(2);
        gameSingle.setParentId(0);
        gameSingle.setName("操盘后台");
        gameSingle.setLevels(1);
        gameSingle.setIsmenu(1);
        gameSingle.setNum(2);
        menus.add(gameSingle);

        MenuNode gameMonitor = new MenuNode();
        gameMonitor.setId(199);
        gameMonitor.setParentId(2);
        gameMonitor.setName("大单监控");
        gameMonitor.setUrl("/Single/toOrderMonitorPage");
        gameMonitor.setLevels(2);
        gameMonitor.setIsmenu(1);
        gameMonitor.setNum(1);
        menus.add(gameMonitor);

        MenuNode gameOperate = new MenuNode();
        gameOperate.setId(200);
        gameOperate.setParentId(2);
        gameOperate.setName("赛事资料操盘");
        gameOperate.setUrl("/Operate/toMatchesInfoOperatePage");
        gameOperate.setLevels(2);
        gameOperate.setIsmenu(1);
        gameOperate.setNum(2);
        menus.add(gameOperate);

        MenuNode gameOneBet = new MenuNode();
        gameOneBet.setId(201);
        gameOneBet.setParentId(2);
        gameOneBet.setName("单场受注监控");
        gameOneBet.setUrl("/Monitor/toOneBetMonitor");
        gameOneBet.setLevels(2);
        gameOneBet.setIsmenu(1);
        gameOneBet.setNum(3);
        menus.add(gameOneBet);

        MenuNode gameUnbalan = new MenuNode();
        gameUnbalan.setId(202);
        gameUnbalan.setParentId(2);
        gameUnbalan.setName("单场失衡监控");
        gameUnbalan.setUrl("/Unbalan/toMatchUnbalance");
        gameUnbalan.setLevels(2);
        gameUnbalan.setIsmenu(1);
        gameUnbalan.setNum(4);
        menus.add(gameUnbalan);

        MenuNode gameProfit = new MenuNode();
        gameProfit.setId(190);
        gameProfit.setParentId(2);
        gameProfit.setName("返还率监控");
        gameProfit.setUrl("/Profit/toUserProfitMonitorPage");
        gameProfit.setLevels(2);
        gameProfit.setIsmenu(1);
        gameProfit.setNum(5);
        menus.add(gameProfit);

        List<MenuNode> titles = MenuNode.buildTitle(menus);
        model.addAttribute("titles", titles);

        return "/index.html";
    }


    @RequestMapping("/blackboard")
    public String blackboard(){
        return "/blackboard.html";
    }

}

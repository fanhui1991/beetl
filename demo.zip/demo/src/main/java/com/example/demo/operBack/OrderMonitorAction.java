package com.example.demo.operBack;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 大单监控
 */

@Controller
@RequestMapping("/Single")
public class OrderMonitorAction {

    private String PREFIX = "/operBack/single/";

    protected static final Logger LOG = LoggerFactory.getLogger(OrderMonitorAction.class);

    /**
     * 默认时间格式
     **/
    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";

    /*
    * 进入大单监控列表页
    * */
    @RequestMapping(value = "/toOrderMonitorPage", method = {RequestMethod.GET,
            RequestMethod.POST})
    public ModelAndView toOrderMonitorPage(HttpServletRequest request, HttpServletResponse response) throws ParseException {
        String backBenginTime = request.getParameter("begin_time");
        String backEndTime = request.getParameter("end_time");
        ModelAndView mav = new ModelAndView(PREFIX+"orderMonitor.html");
        if(StringUtils.isNotBlank(backBenginTime) && StringUtils.isNotBlank(backEndTime)){
            mav.addObject("curDate1",backBenginTime);
            mav.addObject("nextDate1",backEndTime);
        }else {
            Calendar calendar = Calendar.getInstance();
            Calendar calen = Calendar.getInstance();
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String newTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calendar.getTime());
            String cDate = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calendar.getTime());
            Date d1 = df.parse(newTime);
            Date d2 = df.parse(cDate);
            String curDate1;
            String nextDate1;
            long diff = d1.getTime() - d2.getTime();
            if (diff < 0) {
                calen.add(Calendar.DATE, -1);
                curDate1 = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calen.getTime());
                nextDate1 = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calendar.getTime());
            } else {
                calen.add(Calendar.DATE, 1);
                curDate1 = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calendar.getTime());
                nextDate1 = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calen.getTime());
            }
            mav.addObject("curDate1", curDate1);
            mav.addObject("nextDate1", nextDate1);
        }
        return mav;
    }

    /*
    * 进入某个用户的投注列表页
    * TODO
    * */
    @RequestMapping(value = "/toUserOrderMonitorPage", method = {RequestMethod.GET,
            RequestMethod.POST})
    public ModelAndView toUserOrderMonitorPage(HttpServletRequest request, HttpServletResponse response) {
        ModelAndView mav = new ModelAndView(PREFIX+"orderMonitorOfOneUser.html");
        mav.addObject("begin_time", request.getParameter("begin_time"));
        mav.addObject("end_time", request.getParameter("end_time"));
        mav.addObject("user_id", request.getParameter("user_id"));
        mav.addObject("match_id", request.getParameter("match_id"));
        mav.addObject("min_item_money_f", request.getParameter("min_item_money_f"));
        mav.addObject("min_prize_money_f", request.getParameter("min_prize_money_f"));
        return mav;
    }

    /*
    * 查询投注单详情页
    * TODO
    * */
    @RequestMapping(value = "/toOrderMonitorDetailPage/{item_id}", method = {RequestMethod.GET,
            RequestMethod.POST})
    public ModelAndView toOrderMonitorDetailPage(@PathVariable(required = true) String item_id, HttpServletRequest request, HttpServletResponse response) {
        ModelAndView mav = new ModelAndView(PREFIX+"orderMonitorDetailPage.html");
        mav.addObject("item_id", item_id);
        return mav;
    }

    /**
     * TODO
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/queryOrderItemList", method = {RequestMethod.GET, RequestMethod.POST})
    public
    @ResponseBody
    Map queryOrderItemList(HttpServletRequest request, HttpServletResponse response) {
        HashMap<String, Object> rst = new HashMap<String, Object>();
        List<Map<String, Object>> data = new ArrayList<Map<String, Object>>();
        Map<String, Object> map = new HashMap<>();
        map.put("CLIENT_PROPERTIES","尤文图斯  (中)-0.5/1@1.04");
        map.put("MATCH_ODDS","1.04");
        map.put("abnormal_status","0");
        map.put("away_team_name","AC米兰");
        map.put("bets_type","");
        map.put("bj",0);
        map.put("channel_code","XYC");
        map.put("cj",0);
        map.put("away_team_name",0);
        map.put("home_team_name","尤文图斯  (中)");
        map.put("is_inplay",1);
        map.put("item_id","09376ce1896b44fbb624041505221a45");
        map.put("away_team_name","AC米兰");
        map.put("item_money_1",1);
        map.put("item_status",10);
        map.put("league_name","意大利杯");
        map.put("match_id","6892519");
        map.put("match_time","2018-05-10 02:45:00");
        map.put("pay_time","2018-05-09 11:36:59");
        map.put("play_id","70102");
        map.put("play_type","20");
        map.put("prize_money",0);
        map.put("score","  ");
        map.put("sport_type","S");
        map.put("user_id","68002670315191444211");
        map.put("user_name","160977");
        data.add(map);
        rst.put("rows", data);
        rst.put("total", 1);

        return rst;
    }

    /**
     * TODO
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/queryOrderItemDetail", method = {RequestMethod.GET, RequestMethod.POST})
    public
    @ResponseBody
    Map queryOrderItemDetail(HttpServletRequest request, HttpServletResponse response) {
        HashMap<String, Object> rst = new HashMap<String, Object>();
        String item_id = request.getParameter("item_id");
        try {
            List<HashMap<String,Object>> data = new ArrayList<HashMap<String,Object>>();
            HashMap<String,Object> map = new HashMap<String,Object>();
            map.put("bets_info","尤文图斯  (中)-0.5/1@1.04");
            map.put("away_team_name","AC米兰");
            map.put("bets_type","全场让球 - 赛前");
            map.put("home_team_name","尤文图斯  (中)");
            map.put("it_cost","全部");
            map.put("item_money",1);
            map.put("item_status",10);
            map.put("league_name","意大利杯");
            map.put("match_id","6892519");
            map.put("match_odds","1.04");
            map.put("match_time","2018-05-10 02:45:00");
            map.put("pay_time","2018-05-09 11:36:59");
            map.put("play_type","20");
            map.put("prize_money",0);
            map.put("score","  ");
            map.put("sport_type","S");
            map.put("user_name","160977");
            data.add(map);
            rst.put("data", data);
            rst.put("success", "true");
        } catch (Exception e) {
            LOG.error("大单监控页面查询投注详情时发生异常:{} - {}", item_id, e.getMessage(), e);
            rst.put("success", "false");
        }
        return rst;
    }

    /**
     * TODO
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/updateItemStatus", method = {RequestMethod.GET,
            RequestMethod.POST})
    public @ResponseBody
    HashMap<String, Object> updateItemStatus(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HashMap<String, Object> map = new HashMap<String, Object>();
        map.put("res_code",1);
        map.put("res_msg","订单取消成功！");
        return map;
    }
}


package com.example.demo.game;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by zyl
 * 订单管理
 */
@Controller
@RequestMapping("/Order")
public class GameOrderAction {
    protected static final Logger LOG = LoggerFactory.getLogger(GameOrderAction.class);

    private String PREFIX = "/gameManage/order/";


    @RequestMapping(value = "/toYsOrderListPage", method = {RequestMethod.GET,
            RequestMethod.POST})
    public String ysOrderListPage(Model model) throws ParseException {
        Calendar calendar = Calendar.getInstance();
        Calendar calen = Calendar.getInstance();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String newTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calendar.getTime());
        String cDate = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calendar.getTime());
        Date d1 = df.parse(newTime);
        Date d2 = df.parse(cDate);
        String curDate1;
        String nextDate1;
        long diff = d1.getTime() - d2.getTime();
        if(diff < 0){
            calen.add(Calendar.DATE, -1);
            curDate1 = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calen.getTime());
            nextDate1 = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calendar.getTime());
        }else {
            calen.add(Calendar.DATE, 1);
            curDate1 = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calendar.getTime());
            nextDate1 = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calen.getTime());
        }
        model.addAttribute("curDate1", curDate1);
        model.addAttribute("nextDate1", nextDate1);
        return PREFIX+"ysOrderList.html";
    }

//    YS订单查询
    @RequestMapping(value = "/queryYsOrderList", method = {RequestMethod.POST, RequestMethod.GET})
    public @ResponseBody
    Map<String, Object> ysOrderList(
            HttpServletRequest request,
            HttpServletResponse response) {
        Map<String, Object> resMap = new HashMap<String, Object>();
        String match = request.getParameter("match");

        int totalRows = 1;
        List<Map<String, Object>> data = new ArrayList<Map<String, Object>>();
        Map<String, Object> map = new HashMap<>();
        map.put("CLIENT_PROPERTIES","尤文图斯  (中)-0.5/1@1.04");
        map.put("MATCH_ODDS","1.04");
        map.put("abnormal_status","0");
        map.put("away_team_name","AC米兰");
        map.put("bets_type","");
        map.put("bj",0);
        map.put("channel_code","XYC");
        map.put("cj",0);
        map.put("away_team_name",0);
        map.put("home_team_name","尤文图斯  (中)");
        map.put("is_inplay",1);
        map.put("item_id","09376ce1896b44fbb624041505221a45");
        map.put("away_team_name","AC米兰");
        map.put("item_money_1",1);
        map.put("item_status",10);
        map.put("league_name","意大利杯");
        map.put("match_id","6892519");
        map.put("match_time","2018-05-10 02:45:00");
        map.put("pay_time","2018-05-09 11:36:59");
        map.put("play_id","70102");
        map.put("play_type","20");
        map.put("prize_money",0);
        map.put("score","  ");
        map.put("sport_type","S");
        map.put("user_id","68002670315191444211");
        map.put("user_name","160977");
        data.add(map);
        resMap.put("rows", data);
        resMap.put("total", totalRows);
        return resMap;
    }

    //订单异常标记
    @RequestMapping(value = "/updateExcept", method = {RequestMethod.GET,
            RequestMethod.POST})
    public @ResponseBody
    HashMap updateExcept(HttpServletRequest request, HttpServletResponse response) {
        HashMap<String, Object> res = new HashMap<String, Object>();
        res.put("res_code", "1");
        res.put("res_msg", "更变订单异常成功");

        return res;
    }

    /**
     * 手动算奖接口
     * @param map
     * @return
     */
    @RequestMapping(value = "/QuerySetPrize", method = {RequestMethod.GET,
            RequestMethod.POST})
    @ResponseBody
    public Object SetPrize(@RequestParam Map map) throws IOException, InterruptedException {
        HashMap<String,Object> res=new HashMap<String,Object>();
        res.put("res_code","SUCCESS");
        res.put("res_msg","操作成功");
        return res;
    }

}

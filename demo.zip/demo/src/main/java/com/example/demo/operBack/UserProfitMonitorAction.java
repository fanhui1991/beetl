package com.example.demo.operBack;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Function: 返奖率监控
 */
@Controller
@RequestMapping("/Profit")
public class UserProfitMonitorAction {
    private String PREFIX = "/operBack/monitor/";
    
    private static final Logger LOG = LoggerFactory.getLogger(UserProfitMonitorAction.class);

    /**
     * 默认时间格式
     **/
    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";


    //用户返还率监控
    @RequestMapping(value = "/toUserProfitMonitorPage", method = {RequestMethod.GET, RequestMethod.POST})
    public ModelAndView toUserProfitMonitorPage(HttpServletRequest request, HttpServletResponse response) {
        ModelAndView mav = new ModelAndView(PREFIX+"userProfitMonitor.html");
        Calendar calendar = Calendar.getInstance();
        Calendar calen = Calendar.getInstance();
        calendar.add(Calendar.DATE, -2);//得到后一天（如果前一天就-1）
        calen.add(Calendar.DATE, 1);
        String curDate = new SimpleDateFormat("yyyy-MM-dd 00:00:00").format(calendar.getTime());
        String nextDate = new SimpleDateFormat("yyyy-MM-dd 00:00:00").format(calen.getTime());
        mav.addObject("curDate",curDate);
        mav.addObject("nextDate",nextDate);
        return mav;
    }

    @RequestMapping(value = "/queryUserProfitList", method = {RequestMethod.GET, RequestMethod.POST})
    public
    @ResponseBody
    Map queryUserProfitList(HttpServletRequest request, HttpServletResponse response) {
        HashMap<String, Object> result = new HashMap<String, Object>();
        try {
            List<HashMap<String,Object>> data = new ArrayList<HashMap<String,Object>>();
            HashMap<String,Object> res = new HashMap<String,Object>();
            res.put("item_money",6000);
            res.put("prize_money",202290);
            res.put("profit_rate","3372%");
            res.put("user_acct","59183990");
            res.put("user_id","28345256587299159295");
            res.put("yingkui_money",-196290);
            data.add(res);
            result.put("rows", data);
            result.put("total", 1);
        } catch (Exception e) {
            LOG.error("查询用户投注返还率列表时发生异常:", e.getMessage(), e);
            result.put("success", "false");
        }
        return result;
    }
}

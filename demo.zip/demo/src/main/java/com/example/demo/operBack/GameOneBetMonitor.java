package com.example.demo.operBack;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by zyl
 * 单场受注监控
 */
@Controller
@RequestMapping("/Monitor")
public class GameOneBetMonitor {

    private String PREFIX = "/operBack/monitor/";



    @RequestMapping("/toOneBetMonitor")
    public String betMonitorIndex(Model model) throws ParseException {
        Calendar calendar = Calendar.getInstance();
        Calendar calen = Calendar.getInstance();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String newTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calendar.getTime());
        String cDate = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calendar.getTime());
        Date d1 = df.parse(newTime);
        Date d2 = df.parse(cDate);
        String curDate1;
        String nextDate1;
        long diff = d1.getTime() - d2.getTime();
        if(diff < 0){
            calen.add(Calendar.DATE, -1);
            curDate1 = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calen.getTime());
            nextDate1 = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calendar.getTime());
        }else {
            calen.add(Calendar.DATE, 1);
            curDate1 = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calendar.getTime());
            nextDate1 = new SimpleDateFormat("yyyy-MM-dd 12:00:00").format(calen.getTime());
        }
        model.addAttribute("curDate1",curDate1);
        model.addAttribute("nextDate1",nextDate1);
        return PREFIX+"gameOneBetMonitor.html";
    }


    /**
     * queryBetMonitorList.do
     * 受注页面列表
     */
    @RequestMapping("/queryBetMonitorList")
    @ResponseBody
    public HashMap<String,Object> queryBetMonitorList(@RequestParam(required = false) HashMap map){
        HashMap<String,Object> resMap = new HashMap<String, Object>();
        List<HashMap<String,Object>> betList = new ArrayList<HashMap<String,Object>>();
        HashMap<String,Object> res = new HashMap<String,Object>();
        res.put("item_money",11814);
        res.put("match_id","7182540");
        res.put("match_time","2018-06-16 12:30:00");
        res.put("prize_money",13726.47);
        res.put("rate","116.00%");
        res.put("ref_status",1);
        res.put("team","南墨尔本 (女) VS 阿拉门 (女)");
        res.put("wei_j",188);
        betList.add(res);
        int betCount = 1;
        resMap.put("total", betCount);
        resMap.put("rows", betList);
        return resMap;
    }

}

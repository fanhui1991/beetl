package com.console.modular.console.service.impl;

import com.console.modular.console.dao.UserDao;
import com.console.modular.console.service.UserListService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * Created by FH on 2018/8/27.
 */
@Service("userService")
public class UserServiceImpl implements UserListService {

    @Resource
    UserDao userDao;

    @Override
    public List<Map<String, Object>> queryUserFistList(Map map) {
        List<Map<String, Object>> maps = userDao.queryUserFistList(map);
        return maps;
    }
}

package com.console.modular.console.dao;

import java.util.List;
import java.util.Map;

/**
 * Created by FH on 2018/8/27.
 */
public interface UserDao {

    List<Map<String,Object>> queryUserFistList(Map map);
}

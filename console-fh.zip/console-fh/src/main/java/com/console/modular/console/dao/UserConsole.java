package com.console.modular.console.dao;

/**
 * Created by FH on 2018/8/7.
 */
public interface UserConsole {

}

package com.console.modular.console.service;

import java.util.List;
import java.util.Map;

/**
 * Created by FH on 2018/8/27.
 */
public interface UserListService {

    List<Map<String,Object>> queryUserFistList(Map map);
}

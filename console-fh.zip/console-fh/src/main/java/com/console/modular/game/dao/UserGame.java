package com.console.modular.game.dao;

import java.util.List;
import java.util.Map;

/**
 * Created by FH on 2018/8/7.
 */
public interface UserGame {
    List<Map<String, Object>> queryUserList(Map<String, Object> params);
}

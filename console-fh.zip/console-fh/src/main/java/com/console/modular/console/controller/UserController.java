package com.console.modular.console.controller;

import com.console.modular.console.service.UserListService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by FH on 2018/8/27.
 */

@Controller
@RequestMapping("/user")
public class UserController {

    protected final static Logger Log = LoggerFactory.getLogger(UserController.class);

    private static String PREFIX = "/boKe/";

    @Autowired
    @Qualifier(value = "userService")
    UserListService userListService;


    @RequestMapping("")
    public String  index(Model model) {
        model.addAttribute("itemId", "dddddd");
        return PREFIX + "boKeDome";
    }
    /**
     * @param map
     * @return
     */
    @RequestMapping(value = "/")
    @ResponseBody
    public HashMap<String,Object> appSwitchList(@RequestParam(required = false)HashMap<String,Object> map){
        HashMap<String,Object> resMap = new HashMap<String,Object>();
        resMap.put("1",1);
        resMap.put("2",1);
        String o = resMap.get("2").toString();
        List<Map<String, Object>> list = userListService.queryUserFistList(map);
        resMap.put("list",list);
        return resMap;
    }


    @RequestMapping("/demo")
    public String  demo(Model model) {
        model.addAttribute("hello", "hello");
        return PREFIX + "demo";
    }
}
